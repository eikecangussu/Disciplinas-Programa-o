
package com.mycompany.lab09_q3;

public class CadastroProdutos {
    Produto[] produtos = new Produto[4];
    
    public void imprimir(){
        for(int i = 0; i < produtos.length; i++){
            if(produtos[i] == null) break;
            else{
                System.out.println();
                System.out.println(produtos[i].toString());
            }
        }
    }
    
    public Produto buscar(int codigo) throws ExecaoElementoInexistente{
        boolean encontrado = false;
        int j = -1;
        for(int i = 0; i < produtos.length; i++){
            if(produtos[i] == null) break;
            else if(codigo == produtos[i].getCodigo()){
                System.out.println("Produto encontrado");
                encontrado = true;
                j = i;
                break;
            }
        }
        if (!encontrado){
            throw new ExecaoElementoInexistente("Erro :Produto "+codigo+" não existe na base de dados");
        }
        return produtos[j];
    }
    
    public void inserir(Produto novo) throws ExecaoElementoJaExistente,ExecaoRepositorio{
        boolean inserido = false;
        for(int i = 0; i < produtos.length ; i++){
            if(produtos[i]==null){
                produtos[i] = novo;
                inserido = true;
                break;
            }else{
                if(produtos[i].getCodigo() == novo.getCodigo()){
                    throw new ExecaoElementoJaExistente("Erro: Já existe um produto cadastrado com esse código");
                }
            }
        }
        if(!inserido){
            throw new ExecaoRepositorio("Erro: Não existe espaço para armazenar um novo produto");
        }
    }
    
}
    
