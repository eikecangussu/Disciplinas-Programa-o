
package com.mycompany.lab09_q3;

public class ExecaoRepositorio extends Exception {
    public ExecaoRepositorio(String message){
        super(message);
    }
}
