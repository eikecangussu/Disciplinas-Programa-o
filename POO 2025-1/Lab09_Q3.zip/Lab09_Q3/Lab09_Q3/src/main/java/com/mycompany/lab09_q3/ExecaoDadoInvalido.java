
package com.mycompany.lab09_q3;

public class ExecaoDadoInvalido extends Exception {
    public ExecaoDadoInvalido(String message){
        super(message);
    }
}
