
package com.mycompany.lab09_q3;
import java.util.Scanner;

public class Lab09_Q3 {

    public static void main(String[] args) throws ExecaoElementoInexistente, ExecaoElementoJaExistente, ExecaoRepositorio {
        Scanner sc = new Scanner(System.in);
        CadastroProdutos c = new CadastroProdutos();
        int choice = -1;
        do{
            System.out.println(" 1 - cadastrar produto \n 2 - buscar produto \n 3 - imprimir produtos \n 0 - sair");
            choice = sc.nextInt();
            switch(choice){
                case 1:
                    sc.nextLine();
                    System.out.println("Insira o nome do novo produto");
                    String nome = sc.nextLine();
                    System.out.println("Insira o codigo do novo produto");
                    int codigo = sc.nextInt();
                    System.out.println("Insira o preço do novo produto");
                    double preco = sc.nextDouble();
                    System.out.println("Insira a quantidade em estoque do novo produto");
                    int qtdd = sc.nextInt();
                    Produto novo = new Produto(codigo, nome, preco, qtdd);
                    c.inserir(novo);
                    break;
                case 2:
                    System.out.println("Digite o código a ser buscado");
                    int cod = sc.nextInt();
                    c.buscar(cod);
                    break;
                case 3:
                    c.imprimir();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Esoolha inválida");
                    choice = -1;
                    break;
            }
        }while(choice != 0);
    }
}
