
package com.mycompany.lab09_q3;

public class ExecaoElementoInexistente extends Exception {
    public ExecaoElementoInexistente(String message){
        super(message);
    }
}
