
package com.mycompany.lab09_q3;

public class ExecaoElementoJaExistente extends Exception {
    public ExecaoElementoJaExistente(String message){
        super(message);
    }
}
