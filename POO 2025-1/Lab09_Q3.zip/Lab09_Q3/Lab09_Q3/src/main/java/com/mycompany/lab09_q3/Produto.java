
package com.mycompany.lab09_q3;

public class Produto {
    private int codigo;
    private String nome;
    private double preco;
    private int qtEstoque;

    public Produto(int codigo, String nome, double preco, int qtEstoque) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.qtEstoque = qtEstoque;
    }
    
    @Override
    public String toString() {
        return "Produto{" + "codigo=" + codigo + ", nome=" + nome + ", preco=" + preco + ", qtEstoque=" + qtEstoque + '}';
    }
    
    public void setCodigo(int codigo) throws ExecaoDadoInvalido {
        if(codigo<=0)
            throw new ExecaoDadoInvalido("Codigo inválido! Deve ser maior que 0");
        this.codigo = codigo;
    }

    public void setNome(String nome)  throws ExecaoDadoInvalido {
        if(nome==null || nome.equals(""))
            throw new ExecaoDadoInvalido("Nome inválido! Deve ser atribuído algum nome!");
        this.nome = nome;
    }

    public void setPreco(double preco)  throws ExecaoDadoInvalido {
        if(preco<0)
            throw new ExecaoDadoInvalido("Preço inválido! Deve ser maior ou igual a 0!");
        this.preco = preco;
    }

    public void setQtEstoque(int qtEstoque)  throws ExecaoDadoInvalido {
        if(qtEstoque<0)
            throw new ExecaoDadoInvalido("Quantidade inválida! Deve ser maior ou igual a 0!");
        this.qtEstoque = qtEstoque;
    }

    public int getCodigo() {
        return codigo;
    }
    
    
    
}
