package com.mycompany.lab05_q1;
import java.util.ArrayList;

public class Agenda {
    ArrayList<Contato> contatos = new ArrayList();
    
    public void adicionarContato(Contato contato){
        contatos.add(contato);
    }
    
    public boolean removerContato(String nome){
        for(int i = 0; i < this.contatos.size(); i++){
            if (nome.equalsIgnoreCase(contatos.get(i).getNome())){
                contatos.remove(i);
                return true;
            }
        }
        return false;
    }
    
    public Contato buscarContato(String nome){
        for( int i = 0; i < this.contatos.size(); i++ ){
            if (nome.equalsIgnoreCase(this.contatos.get(i).getNome())){
                return this.contatos.get(i);
            }
        }
        return null;
    }
    
    public void listarContatos(){
        System.out.println("Agenda Completa");
        for(int i = 0; i < this.contatos.size(); i++){
            System.out.println(this.contatos.get(i).toString());
        }
    }
}
