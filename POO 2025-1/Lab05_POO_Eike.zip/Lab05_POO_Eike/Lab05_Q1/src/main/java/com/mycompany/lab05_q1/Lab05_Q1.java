
package com.mycompany.lab05_q1;

import java.util.Scanner;

public class Lab05_Q1 {

    public static void main(String[] args) {
        Agenda agenda = new Agenda();
        int choice = 6;
        Scanner sc = new Scanner(System.in);
        while(choice!=0){
            System.out.println("Qual operação deseja realizar?");
            System.out.println("1 - Adicionar Contato");
            System.out.println("2 - Remover Contato");
            System.out.println("3 - Buscar Contato");
            System.out.println("4 - Listar Contatos");
            System.out.println("0 - Sair");
            choice = sc.nextInt();
            sc.nextLine();
            switch(choice){
                case 1:
                    System.out.println("Inserindo novo contato...\n");
                    String nome,telefone,email;
                    System.out.println("Digite o nome do novo contato: ");
                    nome = sc.nextLine();
                    System.out.println("Digite o número de telefone do novo contato: ");
                    telefone =  sc.nextLine();
                    System.out.println("Digite o email do novo contato: ");
                    email = sc.nextLine();
                    Contato contato = new Contato(nome,telefone,email);
                    agenda.contatos.add(contato);
                    break;
                    
                case 2:
                    System.out.println("Qual o nome do contato que você deseja remover?");
                    String nomeR = sc.nextLine();
                    boolean result = agenda.removerContato(nomeR);
                    if(result){
                        System.out.printf("Contato %s removido com sucesso. \n",nomeR);
                    }else System.out.println("Contato não existe na agenda...");
                    break;
                    
                case 3:
                    System.out.println("Qual contato você deseja encontrar?");
                    String nomeB = sc.nextLine();
                    Contato c = agenda.buscarContato(nomeB);
                    if (c!=null){
                        System.out.println("Contato encontrado:");
                        System.out.println(c.toString());
                    }else System.out.println("Contato não encontrado");
                    break;
                case 4:
                    agenda.listarContatos();
                    break;
                case 0:
                    System.out.println("Encerrando...");
                    break;
                default:
                    System.out.println("Insira uma resposta válida");
            }
        }
    }
}
