package com.mycompany.lab05_q2;
import java.util.Scanner;

public class Lab05_Q2 {

    public static void main(String[] args) {
        Dados dados = new Dados();
        int choice = 6;
        Scanner sc = new Scanner(System.in);
        while(choice!=0){
            System.out.println("Qual operação deseja realizar?");
            System.out.println("1 - Cadastrar Livro");
            System.out.println("2 - Cadastrar Pessoa");
            System.out.println("3 - Realizar Emprestimo");
            System.out.println("4 - Devolver Livro");
            System.out.println("5 - Listar livros");
            System.out.println("6 - Listar emprestimos");
            System.out.println("0 - Sair");
            choice = sc.nextInt();
            sc.nextLine();
            boolean buscaPessoa = false;
            boolean buscaL = false;
            switch(choice){
                case 1:
                    System.out.println("Inserindo novo Livro...\n");
                    String titulo,autor;
                    System.out.println("Digite o título do novo livro: ");
                    titulo = sc.nextLine();
                    System.out.println("Digite o autor do novo livro: ");
                    autor =  sc.nextLine();
                    Livro livro = new Livro(titulo,autor);
                    dados.livros.add(livro);
                    break;
                    
                case 2:
                    System.out.println("Qual o nome da pessoa a ser cadastrada?");
                    String nome = sc.nextLine();
                    System.out.println("Qual o cpf da pessoa a ser cadastrada: ");
                    String cpf = sc.nextLine();
                    Pessoa pessoa = new Pessoa(nome,cpf);
                    dados.pessoas.add(pessoa);
                    break;
                    
                case 3:
                    System.out.println("Abrindo Emprestimo...");
                    System.out.println("Livros do acervo:");
                    for(int i = 0; i < dados.livros.size(); i++){
                        System.out.println(dados.livros.get(i).toString());
                        System.out.println();
                    }
                    System.out.println("Qual o seu nome?");
                    String nomePessoa = sc.nextLine();
                    int indicePessoa = 0;
                    for(int i = 0; i < dados.pessoas.size(); i++){
                        if (dados.pessoas.get(i).getNome().equalsIgnoreCase(nomePessoa)){
                            buscaPessoa = true;
                            indicePessoa = i;
                            break;
                        }else{
                            buscaPessoa = false;
                        }
                    }
                    if(buscaPessoa){
                        System.out.println("Qual o titulo do livro que você quer pegar emprestado?");
                        String nomeL = sc.nextLine();
                        for (int i = 0; i < dados.livros.size(); i++){
                            if(nomeL.equalsIgnoreCase(dados.livros.get(i).getTitulo())){
                                if (dados.livros.get(i).isEmprestado()){
                                    System.out.println("Livro não disponível");
                                }
                                else{
                                    Emprestimo emprestimo = new Emprestimo(dados.pessoas.get(indicePessoa),dados.livros.get(i));
                                    dados.emprestimos.add(emprestimo);
                                    boolean emprestou = dados.livros.get(i).emprestar();
                                    System.out.println("Emprestimo realizado");
                                }
                                break;
                            }
                        }
                    }else System.out.println("Pessoa não cadastrada");
                    break;
                    
                case 4:
                    System.out.println("Quem deseja devolver o livro?");
                    String nomeP = sc.nextLine();
                    for(int i = 0; i < dados.pessoas.size(); i++){
                        if (dados.pessoas.get(i).getNome().equalsIgnoreCase(nomeP)){
                            buscaPessoa = true;
                            indicePessoa = i;
                            break;
                        }else{
                            buscaPessoa = false;
                        }
                    }
                    if(buscaPessoa){
                        System.out.println("Qual o título do livro que você deseja devolver?");
                        String nomeLi = sc.nextLine();
                        int indiceL = 0;
                        for(int i = 0; i < dados.livros.size(); i++){
                            if (dados.livros.get(i).getTitulo().equalsIgnoreCase(nomeLi)){
                                buscaL = true;
                                indiceL = i;
                                break;
                            }else{
                                buscaL = false;
                            }
                        }
                        if (buscaL){
                            if(dados.livros.get(indiceL).isEmprestado()){
                                boolean buscaEmprestimo = false;
                                for(int j = 0; j < dados.emprestimos.size(); j++){
                                    if (dados.emprestimos.get(j).getPessoa().getNome().equals(nomeP)) {
                                        dados.livros.get(indiceL).devolver();
                                        dados.livros.remove(j);
                                        System.out.println("Livro devolvido com sucesso");
                                        buscaEmprestimo = true;
                                        break;
                                    }
                                    else buscaEmprestimo = false;
                                }
                                if (!buscaEmprestimo)System.out.println("Esse livro não está emprestado para você");
                            }
                        }else System.out.println("Esse livro não pertence ao acervo para que possa devolve-lo");
                    }else System.out.println("Pessoa não cadastrada");
                    break;
                    
                case 5:
                    for(int i = 0; i < dados.livros.size(); i++){
                        System.out.println(dados.livros.get(i).toString());
                        System.out.println("");
                    }
                    break;
                        
                case 6:
                    for(int i = 0; i < dados.emprestimos.size(); i++){
                        System.out.println(dados.emprestimos.get(i).toString());
                }
                    break;
                    
                case 0:
                    System.out.println("Encerrando...");
                    break;
                    
                default:
                    System.out.println("Insira uma resposta válida");
                    break;
            }
        }
    }
}
