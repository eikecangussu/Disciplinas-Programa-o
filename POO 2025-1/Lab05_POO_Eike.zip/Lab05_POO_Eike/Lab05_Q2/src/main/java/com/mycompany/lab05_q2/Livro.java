
package com.mycompany.lab05_q2;

public class Livro {
    private String titulo;
    private String autor;
    private boolean emprestado;

    public Livro(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
        this.emprestado = false;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public boolean isEmprestado() {
        return emprestado;
    }
    
    public boolean emprestar(){
        if(this.emprestado){
            return false;
        }else{
            this.emprestado = true;
            return true;
        }
    }
    
    public boolean devolver(){
        if(this.emprestado){
            this.emprestado = false;
            return true;
        }else return false;
    }
    
    public String toString(){
        String disponibilidade = new String();
        if (emprestado){
            disponibilidade = "Indisponível";
        }else disponibilidade = "Disponível";
        return String.format("Nome do Livro: %s\nAutor: %s\nDisponibilidade: %s", this.titulo,this.autor,disponibilidade);
    }
    
    
}
