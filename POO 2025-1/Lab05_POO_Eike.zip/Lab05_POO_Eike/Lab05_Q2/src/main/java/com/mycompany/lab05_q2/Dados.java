
package com.mycompany.lab05_q2;
import java.util.ArrayList;

public class Dados {
    
    ArrayList<Pessoa> pessoas = new ArrayList();
    ArrayList<Livro> livros = new ArrayList();
    ArrayList<Emprestimo> emprestimos = new ArrayList();
    
}