package io;

import java.util.List;
import model.Fornecedor;
import service.CadastroFornecedores;

public class LeitorFornecedores {

    public void lerFornecedores(CadastroFornecedores cadastroFornecedores, String filePath) {
        List<String[]> dados = CSVREADER.read(filePath, true);

        for (String[] campos : dados) {
            try {
                if (campos.length < 6) {
                    System.err.println("Linha com número de campos incorreto no CSV de Fornecedores.");
                    continue;
                }
                Fornecedor novoFornecedor = new Fornecedor(
                        Integer.parseInt(campos[0]),
                        campos[1],
                        campos[2],
                        campos[3],
                        campos[4],
                        campos[5]
                );
                cadastroFornecedores.inserirFornecedor(novoFornecedor);
            } catch (NumberFormatException e) {
                System.err.println("Linha inválida no CSV de Fornecedores: erro ao converter código.");
            }
        }
    }
}