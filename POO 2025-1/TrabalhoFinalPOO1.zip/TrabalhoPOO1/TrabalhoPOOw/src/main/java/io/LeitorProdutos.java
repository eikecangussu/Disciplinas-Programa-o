package io;

import java.util.List;
import model.Produto;
import service.CadastroProdutos;

public class LeitorProdutos {

    public static void carregarProdutos(String caminhoCSV, CadastroProdutos cadastro) {
        List<String[]> linhas = CSVREADER.read(caminhoCSV, true);

        for (String[] campos : linhas) {
            try {
                Produto p = new Produto(
                        campos[1],
                        Integer.parseInt(campos[2]),
                        Integer.parseInt(campos[3]),
                        Double.parseDouble(campos[4].replace(",", ".")),
                        Integer.parseInt(campos[5]),
                        Integer.parseInt(campos[0])
                );
                cadastro.inserirProduto(p);
            } catch (NumberFormatException e) {
                System.err.println("Linha inválida no CSV de Produtos: erro ao converter números.");
            }
        }
    }
}