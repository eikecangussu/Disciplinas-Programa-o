package io;

import java.util.List;
import model.Produto;
import model.Compra;
import service.CadastroProdutos;
import service.CadastroCompras;

public class LeitorCompras {

    public static void carregarCompras(String caminhoCSV, CadastroCompras cadastroCompras, CadastroProdutos cadastroProdutos) {
        List<String[]> linhas = CSVREADER.read(caminhoCSV, true);

        for (String[] campos : linhas) {
            try {
                Produto produto = cadastroProdutos.buscarProduto(Integer.parseInt(campos[3]));

                if (produto != null) {
                    Compra c = new Compra(
                            Integer.parseInt(campos[0]),
                            Integer.parseInt(campos[1]),
                            campos[2],
                            produto,
                            Integer.parseInt(campos[4])
                    );

                    cadastroCompras.inserirCompra(c);

                    int estoqueAtual = produto.getEstoqueAtual();
                    produto.setEstoqueAtual(estoqueAtual + c.getQuantidade());

                } else {
                    System.err.println("⚠ Produto com código " + campos[3] + " não encontrado no cadastro.");
                }

            } catch (NumberFormatException e) {
                System.err.println("Linha inválida no CSV de Compras: erro ao converter números.");
            }
        }
    }
}