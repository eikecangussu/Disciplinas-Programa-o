package io;

import model.*;
import java.util.ArrayList;
import java.util.List;

public class EscritorRelatorios {

    public static final String[] CABECALHO_VENDAS = { "cliente_codigo", "data", "produto_codigo", "quantidade", "pagamento", "valorVenda" };
    public static final String[] CABECALHO_COMPRAS = { "notaFiscal", "fornecedor_codigo", "data", "produto_codigo", "quantidade", "valorCompra" };

    public static void salvarVendas(String arquivo, List<Venda> vendas) {
        List<String[]> dados = new ArrayList<>();
        for (Venda v : vendas) {
            dados.add(new String[]{
                    String.valueOf(v.getCliente()),
                    v.getData(),
                    String.valueOf(v.getProduto()),
                    String.valueOf(v.getQuantidade()),
                    v.getPagamento(),
                    String.valueOf(v.getValorVenda()).replace('.', ',')
            });
        }
        CSVWRITER.write(arquivo, CABECALHO_VENDAS, dados);
    }

    public static void salvarCompras(String arquivo, List<Compra> compras) {
        List<String[]> dados = new ArrayList<>();
        for (Compra c : compras) {
            dados.add(new String[]{
                    String.valueOf(c.getNotaFiscal()),
                    String.valueOf(c.getFornecedor()),
                    c.getData(),
                    String.valueOf(c.getProduto().getCodigo()),
                    String.valueOf(c.getQuantidade()),
                    String.valueOf(c.getValorCompra()).replace('.', ',')
            });
        }
        CSVWRITER.write(arquivo, CABECALHO_COMPRAS, dados);
    }
}