package io;

import java.util.List;
import model.Cliente;
import model.ClientePF;
import model.ClientePJ;
import service.CadastroClientes;

public class LeitorClientes {

    public void lerClientes(CadastroClientes cadastroClientes, String filePath) {
        List<String[]> dados = CSVREADER.read(filePath, true);

        for (String[] campos : dados) {
            try {
                Cliente novoCliente;
                int id = Integer.parseInt(campos[0]);
                if (campos.length > 5 && campos[5].equalsIgnoreCase("F")) {
                    novoCliente = new ClientePF(id, campos[1], campos[2], campos[3], campos[4], campos[5], campos[6]);
                } else if (campos.length > 7 && campos[5].equalsIgnoreCase("J")) {
                    novoCliente = new ClientePJ(campos[6], campos[7], id, campos[1], campos[2], campos[3], campos[4], campos[5]);
                } else {
                    System.err.println("Linha inválida no CSV de Clientes: tipo de cliente desconhecido ou campos insuficientes.");
                    continue;
                }
                cadastroClientes.inserirCliente(novoCliente);
            } catch (NumberFormatException e) {
                System.err.println("Linha inválida no CSV de Clientes: erro ao converter ID.");
            }
        }
    }
}