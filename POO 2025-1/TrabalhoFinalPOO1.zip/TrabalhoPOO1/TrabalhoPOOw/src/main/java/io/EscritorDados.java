package io;

import model.*;
import java.util.ArrayList;
import java.util.List;

public class EscritorDados {

    public static final String[] CABECALHO_CLIENTES = {"codigo", "nome", "endereco", "telefone", "dtCadastro", "tipo", "cpf_cnpj", "inscEstadual"};
    public static final String[] CABECALHO_FORNECEDORES = {"codigo", "nome", "endereco", "telefone", "cnpj", "pessoa_contato"};
    public static final String[] CABECALHO_PRODUTOS = {"codigo", "descricao", "estoque_minimo", "estoque_atual", "valor_custo", "percentual_lucro"};


    public static void salvarClientes(String arquivo, List<Cliente> clientes) {
        List<String[]> dados = new ArrayList<>();
        for (Cliente cliente : clientes) {
            if (cliente instanceof ClientePF) {
                ClientePF pf = (ClientePF) cliente;
                dados.add(new String[]{String.valueOf(pf.getId()), pf.getNome(), pf.getEndereco(), pf.getTelefone(), pf.getDtCadastro(), "F", pf.getCpf(), ""});
            } else if (cliente instanceof ClientePJ) {
                ClientePJ pj = (ClientePJ) cliente;
                dados.add(new String[]{
                        String.valueOf(pj.getId()),
                        pj.getNome(),
                        pj.getEndereco(),
                        pj.getTelefone(),
                        pj.getDtCadastro(),
                        "J",
                        pj.getCnpj(),
                        pj.getInscEstadual()
                });
            }
        }
        CSVWRITER.write(arquivo, CABECALHO_CLIENTES, dados);
    }

    public static void salvarFornecedores(String arquivo, List<Fornecedor> fornecedores) {
        List<String[]> dados = new ArrayList<>();
        for (Fornecedor f : fornecedores) {
            dados.add(new String[]{
                    String.valueOf(f.getId()),
                    f.getNomeEmpresa(),
                    f.getEndereco(),
                    f.getTelefone(),
                    f.getCnpj(),
                    f.getPessoaDeContato()
            });
        }
        CSVWRITER.write(arquivo, CABECALHO_FORNECEDORES, dados);
    }

    public static void salvarProdutos(String arquivo, List<Produto> produtos) {
        List<String[]> dados = new ArrayList<>();
        for (Produto p : produtos) {
            dados.add(new String[]{
                    String.valueOf(p.getCodigo()),
                    p.getDescricao(),
                    String.valueOf(p.getEstoqueMinimo()),
                    String.valueOf(p.getEstoqueAtual()),
                    String.valueOf(p.getValorCusto()).replace('.', ','),
                    String.valueOf(p.getPercentualLucro())
            });
        }
        CSVWRITER.write(arquivo, CABECALHO_PRODUTOS, dados);
    }
}