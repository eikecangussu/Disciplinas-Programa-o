package io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVREADER {

    private static final String SEPARATOR = ";";

    public static List<String[]> read(String filePath, boolean cabecalho) {
        List<String[]> linhas = new ArrayList<>();
        String linha;
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            if (cabecalho && br.ready()) {
                br.readLine();
            }
            while ((linha = br.readLine()) != null) {
                if (!linha.trim().isEmpty()) {
                    String[] data = linha.split(SEPARATOR);
                    linhas.add(data);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro de I/O.");
            System.exit(1);
        }
        return linhas;
    }
}