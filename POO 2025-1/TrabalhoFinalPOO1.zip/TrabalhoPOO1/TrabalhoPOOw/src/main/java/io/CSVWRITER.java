package io;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CSVWRITER {

    private static final String SEPARATOR = ";";

    public static void write(String filePath, String[] cabecalho, List<String[]> data) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            if (cabecalho != null) {
                bw.write(String.join(SEPARATOR, cabecalho));
                bw.newLine();
            }

            for (String[] lineData : data) {
                bw.write(String.join(SEPARATOR, lineData));
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro de I/O.");
            System.exit(1);
        }
    }
}