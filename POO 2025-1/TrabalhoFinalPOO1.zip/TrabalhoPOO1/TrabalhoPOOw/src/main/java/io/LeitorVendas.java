package io;

import java.util.List;
import model.Venda;
import model.Produto;
import service.CadastroProdutos;
import service.CadastroVendas;
import service.CadastroClientes;

public class LeitorVendas {

    public static void carregarVendas(String caminhoCSV, CadastroVendas cadastroVendas,CadastroProdutos cadastroProdutos, CadastroClientes cadastroClientes) {
        List<String[]> linhas = CSVREADER.read(caminhoCSV, true);

        for (String[] campos : linhas) {
            try {
                int codigoCliente = campos[0].isEmpty() ? 0 : Integer.parseInt(campos[0]);
                String data = campos[1];
                int codigoProduto = Integer.parseInt(campos[2]);
                int quantidade = Integer.parseInt(campos[3]);
                String pagamento = campos[4];
                Produto produtoVendido = cadastroProdutos.buscarProduto(codigoProduto);

                if (produtoVendido == null) {
                    System.err.println("Produto com código " + codigoProduto + " não encontrado para a venda. Venda ignorada.");
                    continue;
                }

                double precoVenda = produtoVendido.getPrecoVenda();

                if ("F".equalsIgnoreCase(pagamento) && codigoCliente == 0) {
                    System.err.println("Venda fiado com cliente vazio ignorada.");
                    continue;
                }

                Venda venda = new Venda(codigoCliente, data, codigoProduto, quantidade, pagamento, precoVenda);
                cadastroVendas.inserirVenda(venda);

                produtoVendido.setEstoqueAtual(produtoVendido.getEstoqueAtual() - quantidade);

            } catch (NumberFormatException e) {
                System.err.println("Linha inválida no CSV de Vendas: erro ao converter números.");
            }
        }
    }
}