package report;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import model.*;
import service.CadastroProdutos;
import service.CadastroClientes;
import service.CadastroFornecedores;

public class Relatorios {

    private final CadastroClientes cadClientes;
    private final CadastroFornecedores cadFornecedores;
    private final CadastroProdutos cadProdutos;
    private final List<Venda> vendas;
    private final List<Compra> compras;

    public Relatorios(CadastroClientes cadClientes, CadastroFornecedores cadFornecedores,
                      CadastroProdutos cadProdutos, List<Venda> vendas, List<Compra> compras) {
        this.cadClientes = cadClientes;
        this.cadFornecedores = cadFornecedores;
        this.cadProdutos = cadProdutos;
        this.vendas = vendas;
        this.compras = compras;
    }

    public void gerarTotalAPagar() throws IOException {
        try (FileWriter fw = new FileWriter("1-apagar.csv")) {
            fw.write("nome_fornecedor;cnpj;contato;telefone;valor_a_pagar\n");

            List<Fornecedor> fornecedoresOrdenados = cadFornecedores.getRelacaoFornecedores().stream()
                    .sorted(Comparator.comparing(Fornecedor::getNomeEmpresa))
                    .collect(Collectors.toList());

            for (Fornecedor f : fornecedoresOrdenados) {
                double total = compras.stream()
                        .filter(c -> c.getFornecedor() == f.getId())
                        .mapToDouble(Compra::getValorCompra)
                        .sum();

                fw.write(String.format(Locale.US, "%s;%s;%s;%s;%.2f%n",
                        f.getNomeEmpresa(), f.getCnpj(),
                        f.getPessoaDeContato(), f.getTelefone(), total));
            }
        }
    }

    public void gerarTotalAReceber() throws IOException {
        try (FileWriter fw = new FileWriter("2-areceber.csv")) {
            fw.write("nome_cliente;tipo;cpf_cnpj;telefone;data_cadastro;valor_a_receber\n");

            List<Cliente> clientesOrdenados = cadClientes.getRelacaoClientes().stream()
                    .sorted(Comparator.comparing(Cliente::getNome))
                    .collect(Collectors.toList());

            for (Cliente c : clientesOrdenados) {
                double total = vendas.stream()
                        .filter(v -> v.getCliente() == c.getId())
                        .mapToDouble(Venda::getValorVenda)
                        .sum();

                String doc = (c instanceof ClientePF)
                        ? ((ClientePF) c).getCpf() : ((ClientePJ) c).getCnpj();

                fw.write(String.format(Locale.US, "%s;%s;%s;%s;%s;%.2f%n",
                        c.getNome(), c.getTipo(), doc,
                        c.getTelefone(), c.getDtCadastro(), total));
            }
        }
    }

    private static class ResultadoProduto {
        Produto produto;
        double receita;
        double lucro;

        ResultadoProduto(Produto p, double receita, double lucro) {
            this.produto = p;
            this.receita = receita;
            this.lucro = lucro;
        }
    }

    public void gerarVendasProduto() throws IOException {
        List<ResultadoProduto> resultados = new ArrayList<>();

        for (Produto p : cadProdutos.getRelacaoProdutos()) {
            double receita = vendas.stream()
                    .filter(v -> v.getProduto() == p.getCodigo())
                    .mapToDouble(Venda::getValorVenda)
                    .sum();

            double custoDasVendas = vendas.stream()
                    .filter(v -> v.getProduto() == p.getCodigo())
                    .mapToDouble(v -> p.getValorCusto() * v.getQuantidade())
                    .sum();

            resultados.add(new ResultadoProduto(p, receita, receita - custoDasVendas));
        }

        resultados.sort(Comparator.comparingDouble((ResultadoProduto r) -> r.lucro).reversed()
                .thenComparing(r -> r.produto.getCodigo()));

        try (FileWriter fw = new FileWriter("3-vendasprod.csv")) {
            fw.write("codigo_produto;descricao;receita_bruta;lucro\n");

            for (ResultadoProduto res : resultados) {
                fw.write(String.format(Locale.US, "%d;%s;%.2f;%.2f%n",
                        res.produto.getCodigo(), res.produto.getDescricao(), res.receita, res.lucro));
            }
        }
    }

    public void gerarVendasPagamento() throws IOException {
        Map<String, Double> receitaPorPgto = new HashMap<>();
        Map<String, Double> custoPorPgto = new HashMap<>();

        for (Venda v : vendas) {
            Produto p = cadProdutos.buscarProduto(v.getProduto());
            if (p != null) {
                receitaPorPgto.merge(v.getPagamento(), v.getValorVenda(), Double::sum);
                custoPorPgto.merge(v.getPagamento(), p.getValorCusto() * v.getQuantidade(), Double::sum);
            }
        }

        List<String> formasDePagamento = new ArrayList<>(receitaPorPgto.keySet());

        formasDePagamento.sort((pgto1, pgto2) -> {
            double lucro1 = receitaPorPgto.getOrDefault(pgto1, 0.0) - custoPorPgto.getOrDefault(pgto1, 0.0);
            double lucro2 = receitaPorPgto.getOrDefault(pgto2, 0.0) - custoPorPgto.getOrDefault(pgto2, 0.0);

            int comparacaoLucro = Double.compare(lucro2, lucro1);
            if (comparacaoLucro != 0) {
                return comparacaoLucro;
            }

            return pgto1.compareTo(pgto2);
        });

        try (FileWriter fw = new FileWriter("4-vendaspgto.csv")) {
            fw.write("modo_pagamento;receita_bruta;lucro\n");

            for (String pgto : formasDePagamento) {
                double receita = receitaPorPgto.getOrDefault(pgto, 0.0);
                double lucro = receita - custoPorPgto.getOrDefault(pgto, 0.0);
                fw.write(String.format(Locale.US, "%s;%.2f;%.2f%n", pgto, receita, lucro));
            }
        }
    }

    public void gerarEstoque() throws IOException {
        try (FileWriter fw = new FileWriter("5-estoque.csv")) {
            fw.write("codigo_produto;descricao;qtd_estoque;observacoes\n");

            cadProdutos.getRelacaoProdutos().stream()
                    .sorted(Comparator.comparing(Produto::getDescricao))
                    .forEach(p -> {
                        try {
                            String obs = p.getEstoqueAtual() < p.getEstoqueMinimo() ? "COMPRAR MAIS" : "";
                            fw.write(String.format(Locale.US, "%d;%s;%d;%s%n",
                                    p.getCodigo(), p.getDescricao(), p.getEstoqueAtual(), obs));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
        }
    }

    public void gerarTodosRelatorios() {
        try {
            gerarTotalAPagar();
            gerarTotalAReceber();
            gerarVendasProduto();
            gerarVendasPagamento();
            gerarEstoque();
        } catch (IOException e) {
            System.err.println("Erro ao gerar relatórios: " + e.getMessage());
        }
    }
}