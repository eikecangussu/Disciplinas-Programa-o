package service;

import model.Compra;
import model.Produto;
import java.util.ArrayList;

public class CadastroCompras {

    private final ArrayList<Compra> relacaoCompras;

    public CadastroCompras() {
        this.relacaoCompras = new ArrayList<>();
    }

    public void inserirCompra(Compra nova, CadastroProdutos cadastroProdutos) {
        this.relacaoCompras.add(nova);

        Produto produtoComprado = nova.getProduto();
        int estoqueAntigo = produtoComprado.getEstoqueAtual();
        int quantidadeComprada = nova.getQuantidade();
        produtoComprado.setEstoqueAtual(estoqueAntigo + quantidadeComprada);
    }

    public void inserirCompra(Compra nova) {
        this.relacaoCompras.add(nova);
    }

    public ArrayList<Compra> getRelacaoCompras() {
        return relacaoCompras;
    }
}