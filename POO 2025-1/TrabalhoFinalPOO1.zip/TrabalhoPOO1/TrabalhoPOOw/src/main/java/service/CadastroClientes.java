package service;

import java.util.ArrayList;
import model.Cliente;
import java.util.Scanner;

public class CadastroClientes {

    private final ArrayList<Cliente> relacaoClientes;

    public CadastroClientes() {
        this.relacaoClientes = new ArrayList<>();
    }

    public ArrayList<Cliente> getRelacaoClientes() {
        return relacaoClientes;
    }

    public void inserirCliente(Cliente novo){
        this.relacaoClientes.add(novo);
    }

    public Cliente buscarClientePorId(Scanner scanner){
        System.out.println("\n--- BUSCAR CLIENTE ---");
        System.out.print("Digite o ID do cliente: ");
        try {
            int idBusca = Integer.parseInt(scanner.nextLine());
            for (Cliente cliente : relacaoClientes) {
                if (cliente.getId() == idBusca) {
                    return cliente;
                }
            }
            System.out.println("Cliente com ID '" + idBusca + "' não encontrado.");
        } catch (NumberFormatException e) {
            System.out.println("Erro: ID inválido.");
        }
        return null;
    }
}