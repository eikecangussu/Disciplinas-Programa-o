package service;

import model.Fornecedor;
import java.util.ArrayList;
import java.util.Scanner;

public class CadastroFornecedores {

    private final ArrayList<Fornecedor> relacaoFornecedores;

    public CadastroFornecedores() {
        this.relacaoFornecedores = new ArrayList<>();
    }

    public Fornecedor buscarFornecedor(int idBusca) {
        for (Fornecedor f : relacaoFornecedores) {
            if (f.getId() == idBusca) {
                return f;
            }
        }
        return null;
    }

    public Fornecedor buscarFornecedorPorId(Scanner scanner) {
        System.out.print("Digite o ID do fornecedor: ");
        try {
            int idBusca = Integer.parseInt(scanner.nextLine());
            Fornecedor f = buscarFornecedor(idBusca);
            if (f == null) {
                System.out.println("Fornecedor com ID '" + idBusca + "' não encontrado.");
            }
            return f;
        } catch (NumberFormatException e) {
            System.out.println("Erro: ID inválido.");
        }
        return null;
    }

    public ArrayList<Fornecedor> getRelacaoFornecedores() {
        return relacaoFornecedores;
    }

    public void inserirFornecedor(Fornecedor novo){
        this.relacaoFornecedores.add(novo);
    }
}