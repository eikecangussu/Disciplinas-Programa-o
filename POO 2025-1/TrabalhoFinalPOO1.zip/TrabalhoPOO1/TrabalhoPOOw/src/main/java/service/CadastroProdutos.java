package service;

import model.Produto;
import java.util.ArrayList;
import java.util.Scanner;

public class CadastroProdutos {

    private final ArrayList<Produto> relacaoProdutos;

    public CadastroProdutos() {
        this.relacaoProdutos = new ArrayList<>();
    }

    public Produto buscarProduto(int codigo){
        for (Produto produto : relacaoProdutos){
            if(produto.getCodigo() == codigo){
                return produto;
            }
        }
        return null;
    }

    public Produto buscarProdutoPorId(Scanner scanner) {
        System.out.print("Digite o código do produto: ");
        try {
            int idBusca = Integer.parseInt(scanner.nextLine());
            Produto p = buscarProduto(idBusca);
            if (p == null) {
                System.out.println("Produto com código '" + idBusca + "' não encontrado.");
            }
            return p;
        } catch (NumberFormatException e) {
            System.out.println("Erro: Código inválido.");
        }
        return null;
    }

    public ArrayList<Produto> getRelacaoProdutos() {
        return relacaoProdutos;
    }

    public void inserirProduto(Produto novo) {
        this.relacaoProdutos.add(novo);
    }
}