package service;

import model.Produto;
import model.Venda;
import java.util.ArrayList;

public class CadastroVendas {

    private final ArrayList<Venda> relacaoVendas;

    public CadastroVendas() {
        this.relacaoVendas = new ArrayList<>();
    }

    public void inserirVenda(Venda nova, CadastroProdutos cadastroProdutos) {
        Produto produtoVendido = cadastroProdutos.buscarProduto(nova.getProduto());

        if (produtoVendido.getEstoqueAtual() < nova.getQuantidade()) {
            throw new IllegalArgumentException("Estoque insuficiente para o produto: " + produtoVendido.getDescricao());
        }

        this.relacaoVendas.add(nova);

        produtoVendido.setEstoqueAtual(produtoVendido.getEstoqueAtual() - nova.getQuantidade());
    }

    public void inserirVenda(Venda nova){
        this.relacaoVendas.add(nova);
    }

    public ArrayList<Venda> getRelacaoVendas() {
        return relacaoVendas;
    }

    public ArrayList<Venda> gerarFiados(){
        ArrayList<Venda> fiados = new ArrayList<>();
        for (Venda venda : relacaoVendas) {
            if (venda.getPagamento().equalsIgnoreCase("f")) {
                fiados.add(venda);
            }
        }
        return fiados;
    }
}