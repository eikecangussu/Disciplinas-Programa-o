package model;

public class ClientePF extends Cliente {

    private String cpf;

    public ClientePF(int id, String nome, String endereco, String telefone, String dtCadastro, String tipo, String cpf) {
        super(id, nome, endereco, telefone, dtCadastro, tipo);
        this.cpf = cpf;
    }

    public ClientePF(String nome, String endereco, String telefone, String dtCadastro, String tipo, String cpf) {
        super(nome, endereco, telefone, dtCadastro, tipo);
        this.cpf = cpf;
    }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }
}