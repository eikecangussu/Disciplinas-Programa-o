package model;

public class Fornecedor {

    private static int idGeral = 0;
    private int id;
    private String nomeEmpresa;
    private String endereco;
    private String telefone;
    private String cnpj;
    private String pessoaDeContato;

    public Fornecedor(String nomeEmpresa, String endereco, String telefone, String cnpj, String pessoaDeContato) {
        idGeral++;
        this.id = idGeral;
        this.nomeEmpresa = nomeEmpresa;
        this.endereco = endereco;
        this.telefone = telefone;
        this.cnpj = cnpj;
        this.pessoaDeContato = pessoaDeContato;
    }

    public Fornecedor(int id, String nomeEmpresa, String endereco, String telefone, String cnpj, String pessoaDeContato) {
        this.id = id;
        this.nomeEmpresa = nomeEmpresa;
        this.endereco = endereco;
        this.telefone = telefone;
        this.cnpj = cnpj;
        this.pessoaDeContato = pessoaDeContato;

        if (id > idGeral) {
            idGeral = id;
        }
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNomeEmpresa() { return nomeEmpresa; }
    public void setNomeEmpresa(String nomeEmpresa) { this.nomeEmpresa = nomeEmpresa; }
    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }
    public String getPessoaDeContato() { return pessoaDeContato; }
    public void setPessoaDeContato(String pessoaDeContato) { this.pessoaDeContato = pessoaDeContato; }

    @Override
    public String toString() {
        return String.format("ID: %d - %s", id, nomeEmpresa);
    }
}