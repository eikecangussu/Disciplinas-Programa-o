package model;

public class Compra {

    private int notaFiscal;
    private int fornecedor;
    private String data;
    private Produto produto;
    private int quantidade;
    private double valorCompra;

    public Compra(int notaFiscal, int fornecedor, String data, Produto produto, int quantidade) {
        this.notaFiscal = notaFiscal;
        this.fornecedor = fornecedor;
        this.data = data;
        this.produto = produto;
        this.quantidade = quantidade;
        this.valorCompra = produto.getValorCusto() * quantidade;
    }

    public int getNotaFiscal() { return notaFiscal; }
    public int getFornecedor() { return fornecedor; }
    public String getData() { return data; }
    public Produto getProduto() { return produto; }
    public int getQuantidade() { return quantidade; }
    public double getValorCompra() { return valorCompra; }
}