package model;

public class Produto {

    private static int ultimoCodigo = 0;

    private int codigo;
    private String descricao;
    private int estoqueMinimo;
    private int estoqueAtual;
    private double valorCusto;
    private int percentualLucro;

    public Produto(String descricao, int estoqueMinimo, int estoqueAtual, double valorCusto, int percentualLucro, int codigo) {
        validarValores(estoqueMinimo, estoqueAtual, valorCusto, percentualLucro);
        this.descricao = descricao;
        this.estoqueMinimo = estoqueMinimo;
        this.estoqueAtual = estoqueAtual;
        this.valorCusto = valorCusto;
        this.percentualLucro = percentualLucro;
        this.codigo = codigo;

        if (codigo > ultimoCodigo) {
            ultimoCodigo = codigo;
        }
    }

    public Produto(String descricao, int estoqueMinimo, int estoqueAtual, double valorCusto, int percentualLucro) {
        validarValores(estoqueMinimo, estoqueAtual, valorCusto, percentualLucro);
        this.descricao = descricao;
        this.estoqueMinimo = estoqueMinimo;
        this.estoqueAtual = estoqueAtual;
        this.valorCusto = valorCusto;
        this.percentualLucro = percentualLucro;
        this.codigo = ++ultimoCodigo;
    }

    private void validarValores(int estoqueMinimo, int estoqueAtual, double valorCusto, int percentualLucro) {
        if (estoqueMinimo < 0 || estoqueAtual < 0 || valorCusto < 0 || percentualLucro < 0) {
            throw new IllegalArgumentException("Valores não podem ser negativos.");
        }
    }

    public void setEstoqueAtual(int estoqueAtual) {
        if (estoqueAtual < 0) {
            throw new IllegalArgumentException("Estoque não pode ser negativo.");
        }
        this.estoqueAtual = estoqueAtual;
    }

    public int getCodigo() { return codigo; }
    public String getDescricao() { return descricao; }
    public int getEstoqueMinimo() { return estoqueMinimo; }
    public int getEstoqueAtual() { return estoqueAtual; }
    public double getValorCusto() { return valorCusto; }
    public int getPercentualLucro() { return percentualLucro; }
    public double getPrecoVenda() { return valorCusto * (1 + percentualLucro / 100.0); }

    @Override
    public String toString() {
        return String.format("Cód: %d - %s", codigo, descricao);
    }
}