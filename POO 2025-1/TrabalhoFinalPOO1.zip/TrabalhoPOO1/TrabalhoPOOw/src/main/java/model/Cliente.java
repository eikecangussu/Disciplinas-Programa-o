package model;

public abstract class Cliente {
    private static int idGeral = 0;
    private int id;
    private String nome;
    private String endereco;
    private String telefone;
    private String dtCadastro;
    private String tipo;

    public Cliente(String nome, String endereco, String telefone, String dtCadastro, String tipo) {
        idGeral++;
        this.id = idGeral;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.dtCadastro = dtCadastro;
        this.tipo = tipo;
    }

    public Cliente(int id,String nome, String endereco, String telefone, String dtCadastro, String tipo) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.dtCadastro = dtCadastro;
        this.tipo = tipo;

        if (id > idGeral) {
            idGeral = id;
        }
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getEndereco() { return endereco; }
    public String getTelefone() { return telefone; }
    public String getDtCadastro() { return dtCadastro; }
    public String getTipo() { return tipo; }
    public void setId(int id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public void setDtCadastro(String dtCadastro) { this.dtCadastro = dtCadastro; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    @Override
    public String toString() {
        return String.format("ID: %d - %s", id, nome);
    }
}