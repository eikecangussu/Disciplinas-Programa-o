package model;

import service.CadastroProdutos;

public class Venda {
    private final int cliente;
    private final String data;
    private final int produto;
    private final int quantidade;
    private final String pagamento;
    private final double valorVenda;

    public Venda(int cliente, String data, int produto, int quantidade, String pagamento, CadastroProdutos relacaoProdutos) {
        if(pagamento.equalsIgnoreCase("f")){
            this.cliente = cliente;
        }else{
            this.cliente = 0;
        }
        this.data = data;
        this.produto = produto;
        this.quantidade = quantidade;
        this.pagamento = pagamento;
        this.valorVenda = quantidade*(relacaoProdutos.buscarProduto(produto).getPrecoVenda());
    }

    public Venda(int cliente, String data, int produto, int quantidade, String pagamento, double preco) {
        if(pagamento.equalsIgnoreCase("f")){
            this.cliente = cliente;
        }else{
            this.cliente = 0;
        }
        this.data = data;
        this.produto = produto;
        this.quantidade = quantidade;
        this.pagamento = pagamento;
        this.valorVenda = preco*quantidade;
    }

    public int getCliente() { return cliente; }
    public String getData() { return data; }
    public int getProduto() { return produto; }
    public int getQuantidade() { return quantidade; }
    public String getPagamento() { return pagamento; }
    public double getValorVenda() { return valorVenda; }

    @Override
    public String toString() {
        return "Venda{" + "data=" + data + ", produto=" + produto + ", quantidade=" + quantidade + ", pagamento=" + pagamento + '}';
    }
}