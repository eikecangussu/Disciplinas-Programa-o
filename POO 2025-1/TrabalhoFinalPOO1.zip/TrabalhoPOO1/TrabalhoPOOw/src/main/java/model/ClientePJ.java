
package model;


/**
 *
 * @author eikec
 */

public class ClientePJ extends Cliente {
    
    private String cnpj;
    private String inscEstadual;
    
    public ClientePJ(String cnpj, String inscEstadual,String nome, String endereco, String telefone, String dtCadastro, String tipo) {
        super(nome, endereco, telefone, dtCadastro, tipo);
        this.cnpj = cnpj;
        this.inscEstadual = inscEstadual;
    }
    
    public ClientePJ(String cnpj, String inscEstadual, int id, String nome, String endereco, String telefone, String dtCadastro, String tipo) {
        super(id, nome, endereco, telefone, dtCadastro, tipo);
        this.cnpj = cnpj;
        this.inscEstadual = inscEstadual;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInscEstadual() {
        return inscEstadual;
    }

    public void setInscEstadual(String inscEstadual) {
        this.inscEstadual = inscEstadual;
    }
    
    
    
}
