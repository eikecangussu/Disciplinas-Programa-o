package com.mycompany.trabalhopoow;

import io.*;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.SwingUtilities;
import service.*;
import ui.JanelaPrincipal;
import ui.MenuPrincipal;

/*
Integrantes grupo:
Eike Cangussú
Matheus Alves Martins
Gabriel Vargas
Isaac Covre
Victor Rodrigues
*/

public class TrabalhoPOOw {
    public static void main(String[] args) {
        Scanner scannerEntrada = new Scanner(System.in);
        System.out.println("--- Configuração Inicial do Sistema ---");
        System.out.println("Por favor, informe os nomes dos arquivos CSV ou pressione Enter para usar os padrões:");

        System.out.print("Arquivo de Clientes (padrão: clientes.csv): ");
        String arquivoClientes = scannerEntrada.nextLine();
        if (arquivoClientes.isEmpty()) {
            arquivoClientes = "clientes.csv";
            System.out.println(">> Usando nome padrão: " + arquivoClientes);
        }

        System.out.print("Arquivo de Fornecedores (padrão: fornecedores.csv): ");
        String arquivoFornecedores = scannerEntrada.nextLine();
        if (arquivoFornecedores.isEmpty()) {
            arquivoFornecedores = "fornecedores.csv";
            System.out.println(">> Usando nome padrão: " + arquivoFornecedores);
        }

        System.out.print("Arquivo de Produtos (padrão: produtos.csv): ");
        String arquivoProdutos = scannerEntrada.nextLine();
        if (arquivoProdutos.isEmpty()) {
            arquivoProdutos = "produtos.csv";
            System.out.println(">> Usando nome padrão: " + arquivoProdutos);
        }

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM_yyyy");
        String mesAno = LocalDate.now().format(dtf);
        String arquivoCompras = "compras_" + mesAno + ".csv";
        String arquivoVendas = "vendas_" + mesAno + ".csv";
        System.out.println(">> Usando arquivos de transação para o mês atual: " + arquivoCompras + " e " + arquivoVendas);

        CadastroClientes cadastroClientes = new CadastroClientes();
        CadastroFornecedores cadastroFornecedores = new CadastroFornecedores();
        CadastroProdutos cadastroProdutos = new CadastroProdutos();
        CadastroVendas cadastroVendas = new CadastroVendas();
        CadastroCompras cadastroCompras = new CadastroCompras();

        carregarDados(cadastroClientes, cadastroFornecedores, cadastroProdutos,
                cadastroCompras, cadastroVendas,
                arquivoClientes, arquivoFornecedores, arquivoProdutos,
                arquivoCompras, arquivoVendas);

        System.out.println("\n--- BEM-VINDO AO SISTEMA DE GESTÃO ---");
        System.out.println("Qual interface você deseja usar?");
        System.out.println("1. Interface de Console (CLI)");
        System.out.println("2. Interface Gráfica (GUI)");
        System.out.print(">> Escolha uma opção: ");

        int escolha;
        try {
            escolha = Integer.parseInt(scannerEntrada.nextLine());
        } catch (NumberFormatException e) {
            escolha = -1;
        }

        if (escolha == 1) {
            System.out.println("\nIniciando a interface de console...");
            MenuPrincipal menu = new MenuPrincipal(
                    cadastroClientes, cadastroFornecedores, cadastroProdutos,
                    cadastroVendas, cadastroCompras
            );
            menu.exibir();

            salvarDados(cadastroClientes, cadastroFornecedores, cadastroProdutos,
                    cadastroCompras, cadastroVendas,
                    arquivoClientes, arquivoFornecedores, arquivoProdutos,
                    arquivoCompras, arquivoVendas);
        } else if (escolha == 2) {
            System.out.println("\nIniciando a interface gráfica...");
            final String[] arquivos = {arquivoClientes, arquivoFornecedores, arquivoProdutos, arquivoCompras, arquivoVendas};
            SwingUtilities.invokeLater(() -> {
                JanelaPrincipal janela = new JanelaPrincipal(
                        cadastroClientes, cadastroFornecedores, cadastroProdutos,
                        cadastroVendas, cadastroCompras, arquivos
                );
                janela.setVisible(true);
            });
        } else {
            System.out.println("Opção inválida. Encerrando o programa.");
        }
    }

    private static void carregarDados(CadastroClientes cc, CadastroFornecedores cf, CadastroProdutos cp,
                                      CadastroCompras ccomp, CadastroVendas cv,
                                      String arqClientes, String arqFornecedores, String arqProdutos,
                                      String arqCompras, String arqVendas) {
        File fileClientes = new File(arqClientes);
        if (fileClientes.exists()) {
            new LeitorClientes().lerClientes(cc, arqClientes);
            System.out.println(">> Clientes carregados de '" + arqClientes + "'.");
        } else {
            System.out.println("AVISO: Arquivo '" + arqClientes + "' não encontrado. Criando um novo arquivo.");
            CSVWRITER.write(arqClientes, EscritorDados.CABECALHO_CLIENTES, new ArrayList<>());
        }

        File fileFornecedores = new File(arqFornecedores);
        if (fileFornecedores.exists()) {
            new LeitorFornecedores().lerFornecedores(cf, arqFornecedores);
            System.out.println(">> Fornecedores carregados de '" + arqFornecedores + "'.");
        } else {
            System.out.println("AVISO: Arquivo '" + arqFornecedores + "' não encontrado. Criando um novo arquivo.");
            CSVWRITER.write(arqFornecedores, EscritorDados.CABECALHO_FORNECEDORES, new ArrayList<>());
        }

        File fileProdutos = new File(arqProdutos);
        if (fileProdutos.exists()) {
            LeitorProdutos.carregarProdutos(arqProdutos, cp);
            System.out.println(">> Produtos carregados de '" + arqProdutos + "'.");
        } else {
            System.out.println("AVISO: Arquivo '" + arqProdutos + "' não encontrado. Criando um novo arquivo.");
            CSVWRITER.write(arqProdutos, EscritorDados.CABECALHO_PRODUTOS, new ArrayList<>());
        }

        File fileCompras = new File(arqCompras);
        if (fileCompras.exists()) {
            LeitorCompras.carregarCompras(arqCompras, ccomp, cp);
            System.out.println(">> Compras carregadas de '" + arqCompras + "'.");
        } else {
            System.out.println("AVISO: Arquivo '" + arqCompras + "' não encontrado. Criando um novo arquivo.");
            CSVWRITER.write(arqCompras, EscritorRelatorios.CABECALHO_COMPRAS, new ArrayList<>());
        }

        File fileVendas = new File(arqVendas);
        if (fileVendas.exists()) {
            LeitorVendas.carregarVendas(arqVendas, cv, cp, cc);
            System.out.println(">> Vendas carregadas de '" + arqVendas + "'.");
        } else {
            System.out.println("AVISO: Arquivo '" + arqVendas + "' não encontrado. Criando um novo arquivo.");
            CSVWRITER.write(arqVendas, EscritorRelatorios.CABECALHO_VENDAS, new ArrayList<>());
        }
    }

    private static void salvarDados(CadastroClientes cc, CadastroFornecedores cf, CadastroProdutos cp,
                                    CadastroCompras ccomp, CadastroVendas cv,
                                    String arqClientes, String arqFornecedores, String arqProdutos,
                                    String arqCompras, String arqVendas) {
        try {
            EscritorDados.salvarClientes(arqClientes, cc.getRelacaoClientes());
            EscritorDados.salvarFornecedores(arqFornecedores, cf.getRelacaoFornecedores());
            EscritorDados.salvarProdutos(arqProdutos, cp.getRelacaoProdutos());
            EscritorRelatorios.salvarCompras(arqCompras, ccomp.getRelacaoCompras());
            EscritorRelatorios.salvarVendas(arqVendas, cv.getRelacaoVendas());
            System.out.println("\n>> Dados salvos com sucesso nos arquivos CSV!");
        } catch (Exception e) {
            System.err.println("Erro ao salvar os dados: " + e.getMessage());
        }
    }
}