package ui;

import model.Compra;
import model.Fornecedor;
import model.Produto;
import service.CadastroFornecedores;
import service.CadastroProdutos;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

public class DialogoCompra extends JDialog {
    private JSpinner spnNotaFiscal, spnQuantidade;
    private JComboBox<Fornecedor> cmbFornecedor;
    private JComboBox<Produto> cmbProduto;
    private Compra novaCompra = null;
    private boolean salvo = false;

    public DialogoCompra(Frame owner, CadastroFornecedores cadFornecedores, CadastroProdutos cadProdutos) {
        super(owner, "Registrar Nova Compra", true);
        setLayout(new BorderLayout(10, 10));

        Vector<Fornecedor> fornecedores = new Vector<>(cadFornecedores.getRelacaoFornecedores());
        Vector<Produto> produtos = new Vector<>(cadProdutos.getRelacaoProdutos());

        if (fornecedores.isEmpty() || produtos.isEmpty()) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(owner, "É necessário ter ao menos um fornecedor e um produto cadastrados.", "Cadastro Incompleto", JOptionPane.WARNING_MESSAGE);
                dispose();
            });
            return;
        }

        cmbFornecedor = new JComboBox<>(fornecedores);
        cmbProduto = new JComboBox<>(produtos);
        spnNotaFiscal = new JSpinner(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));
        spnQuantidade = new JSpinner(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));

        add(criarPainelFormulario(), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }

    private void salvar() {
        Fornecedor fornecedor = (Fornecedor) cmbFornecedor.getSelectedItem();
        Produto produto = (Produto) cmbProduto.getSelectedItem();
        int notaFiscal = (int) spnNotaFiscal.getValue();
        int quantidade = (int) spnQuantidade.getValue();

        if (fornecedor == null || produto == null) {
            JOptionPane.showMessageDialog(this, "Selecione um fornecedor e um produto.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String data = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        this.novaCompra = new Compra(notaFiscal, fornecedor.getId(), data, produto, quantidade);
        this.salvo = true;
        dispose();
    }

    public Compra getNovaCompra() { return novaCompra; }
    public boolean isSalvo() { return salvo; }

    private JPanel criarPainelFormulario() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        gbc.gridy = 0; gbc.gridx = 0; painel.add(new JLabel("Nota Fiscal:"), gbc);
        gbc.gridx = 1; painel.add(spnNotaFiscal, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Fornecedor:"), gbc);
        gbc.gridx = 1; painel.add(cmbFornecedor, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Produto:"), gbc);
        gbc.gridx = 1; painel.add(cmbProduto, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Quantidade:"), gbc);
        gbc.gridx = 1; painel.add(spnQuantidade, gbc);
        return painel;
    }
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");
        btnSalvar.addActionListener(e -> salvar());
        btnCancelar.addActionListener(e -> dispose());
        painel.add(btnSalvar); painel.add(btnCancelar);
        return painel;
    }
}