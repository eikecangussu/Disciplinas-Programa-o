package ui;

import model.Produto;
import javax.swing.*;
import java.awt.*;

public class DialogoProduto extends JDialog {
    private JTextField txtDescricao;
    private JSpinner spnEstoqueMinimo, spnEstoqueAtual, spnPercentualLucro, spnValorCusto;
    private Produto produtoResultante;
    private boolean salvo = false;

    public DialogoProduto(Frame owner) { this(owner, null); }
    public DialogoProduto(Frame owner, Produto produto) {
        super(owner, (produto == null ? "Adicionar Produto" : "Editar Produto"), true);
        this.produtoResultante = produto;
        setupUI();
        if (produto != null) {
            preencherFormulario(produto);
        }
    }

    private void setupUI() {
        setLayout(new BorderLayout());
        add(criarPainelFormulario(), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(getOwner());
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }

    private void preencherFormulario(Produto p) {
        txtDescricao.setText(p.getDescricao());
        spnEstoqueMinimo.setValue(p.getEstoqueMinimo());
        spnEstoqueAtual.setValue(p.getEstoqueAtual());
        spnValorCusto.setValue(p.getValorCusto());
        spnPercentualLucro.setValue(p.getPercentualLucro());
        txtDescricao.setEditable(false);
    }

    private void salvar() {
        if (txtDescricao.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Descrição é obrigatória.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            String desc = txtDescricao.getText();
            int estMin = (int) spnEstoqueMinimo.getValue();
            int estAtual = (int) spnEstoqueAtual.getValue();
            double vlrCusto = (double) spnValorCusto.getValue();
            int percLucro = (int) spnPercentualLucro.getValue();

            if (produtoResultante == null) { // Adicionar
                produtoResultante = new Produto(desc, estMin, estAtual, vlrCusto, percLucro);
            } else {
                produtoResultante.setEstoqueAtual(estAtual);
            }
            salvo = true;
            dispose();
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public Produto getProdutoResultante() { return produtoResultante; }
    public boolean isSalvo() { return salvo; }

    private JPanel criarPainelFormulario() {
        JPanel painel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        gbc.gridy = 0; gbc.gridx = 0; painel.add(new JLabel("Descrição:"), gbc);
        gbc.gridx = 1; txtDescricao = new JTextField(25); painel.add(txtDescricao, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Estoque Mínimo:"), gbc);
        gbc.gridx = 1; spnEstoqueMinimo = new JSpinner(new SpinnerNumberModel(0, 0, 9999, 1)); painel.add(spnEstoqueMinimo, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Estoque Atual:"), gbc);
        gbc.gridx = 1; spnEstoqueAtual = new JSpinner(new SpinnerNumberModel(0, 0, 9999, 1)); painel.add(spnEstoqueAtual, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Valor de Custo (R$):"), gbc);
        gbc.gridx = 1; spnValorCusto = new JSpinner(new SpinnerNumberModel(0.0, 0.0, 9999.0, 0.1)); painel.add(spnValorCusto, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Percentual de Lucro (%):"), gbc);
        gbc.gridx = 1; spnPercentualLucro = new JSpinner(new SpinnerNumberModel(0, 0, 9999, 1)); painel.add(spnPercentualLucro, gbc);
        return painel;
    }
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");
        btnSalvar.addActionListener(e -> salvar());
        btnCancelar.addActionListener(e -> dispose());
        painel.add(btnSalvar); painel.add(btnCancelar);
        return painel;
    }
}