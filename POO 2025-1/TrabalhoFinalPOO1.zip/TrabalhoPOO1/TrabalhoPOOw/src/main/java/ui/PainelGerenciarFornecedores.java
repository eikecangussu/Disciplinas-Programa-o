package ui;

import model.Fornecedor;
import service.CadastroFornecedores;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

public class PainelGerenciarFornecedores extends JPanel {
    private final CadastroFornecedores cadastroFornecedores;
    private final JTable tabela;
    private final DefaultTableModel modeloTabela;

    public PainelGerenciarFornecedores(CadastroFornecedores cadastroFornecedores, ActionListener acaoVoltar) {
        this.cadastroFornecedores = cadastroFornecedores;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JLabel("Gerenciamento de Fornecedores", SwingConstants.CENTER), BorderLayout.NORTH);

        String[] colunas = {"ID", "Nome da Empresa", "CNPJ", "Telefone", "Contato"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(modeloTabela);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        JButton btnAdicionar = new JButton("Adicionar");
        JButton btnEditar = new JButton("Editar");
        JButton btnRemover = new JButton("Remover");
        JButton btnVoltar = new JButton("Voltar");

        btnAdicionar.addActionListener(e -> adicionarFornecedor());
        btnEditar.addActionListener(e -> editarFornecedor());
        btnRemover.addActionListener(e -> removerFornecedor());
        btnVoltar.addActionListener(acaoVoltar);

        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnRemover);
        painelBotoes.add(btnVoltar);
        add(painelBotoes, BorderLayout.SOUTH);

        this.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) { atualizarTabela(); }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {}
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {}
        });
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        for (Fornecedor f : cadastroFornecedores.getRelacaoFornecedores()) {
            modeloTabela.addRow(new Object[]{
                    f.getId(), f.getNomeEmpresa(), f.getCnpj(), f.getTelefone(), f.getPessoaDeContato()
            });
        }
    }

    private void adicionarFornecedor() {
        DialogoFornecedor dialogo = new DialogoFornecedor((Frame) SwingUtilities.getWindowAncestor(this));
        dialogo.setVisible(true);
        if (dialogo.isSalvo()) {
            cadastroFornecedores.inserirFornecedor(dialogo.getFornecedorResultante());
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Fornecedor adicionado com sucesso!");
        }
    }

    private void editarFornecedor() {
        int linhaSelecionada = tabela.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um fornecedor para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        Fornecedor fornecedor = cadastroFornecedores.buscarFornecedor(id);

        if (fornecedor != null) {
            DialogoFornecedor dialogo = new DialogoFornecedor((Frame) SwingUtilities.getWindowAncestor(this), fornecedor);
            dialogo.setVisible(true);
            if (dialogo.isSalvo()) {
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Fornecedor atualizado com sucesso!");
            }
        }
    }

    private void removerFornecedor() {
        int linhaSelecionada = tabela.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um fornecedor para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        int confirmacao = JOptionPane.showConfirmDialog(this, "Remover fornecedor com ID " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmacao == JOptionPane.YES_OPTION) {
            Fornecedor fornecedor = cadastroFornecedores.buscarFornecedor(id);
            if (fornecedor != null) {
                cadastroFornecedores.getRelacaoFornecedores().remove(fornecedor);
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Fornecedor removido com sucesso!");
            }
        }
    }
}