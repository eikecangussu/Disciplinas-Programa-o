package ui;

import model.Compra;
import model.Fornecedor;
import service.CadastroCompras;
import service.CadastroFornecedores;
import service.CadastroProdutos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Locale;

public class PainelRegistrarCompras extends JPanel {
    private final CadastroCompras cadastroCompras;
    private final CadastroFornecedores cadastroFornecedores;
    private final CadastroProdutos cadastroProdutos;

    private final JTable tabela;
    private final DefaultTableModel modeloTabela;

    public PainelRegistrarCompras(CadastroCompras ccomp, CadastroFornecedores cf, CadastroProdutos cp, ActionListener acaoVoltar) {
        this.cadastroCompras = ccomp;
        this.cadastroFornecedores = cf;
        this.cadastroProdutos = cp;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JLabel("Registro e Listagem de Compras", SwingConstants.CENTER), BorderLayout.NORTH);

        String[] colunas = {"NF", "Data", "Fornecedor", "Produto", "Qtd", "Valor Total"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(modeloTabela);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        JButton btnAdicionar = new JButton("Registrar Nova Compra");
        JButton btnVoltar = new JButton("Voltar");

        btnAdicionar.addActionListener(e -> registrarNovaCompra());
        btnVoltar.addActionListener(acaoVoltar);

        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnVoltar);
        add(painelBotoes, BorderLayout.SOUTH);

        this.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) { atualizarTabela(); }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {}
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {}
        });
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        for (Compra compra : cadastroCompras.getRelacaoCompras()) {
            Fornecedor f = cadastroFornecedores.buscarFornecedor(compra.getFornecedor());
            String nomeFornecedor = (f != null) ? f.getNomeEmpresa() : "ID " + compra.getFornecedor();

            modeloTabela.addRow(new Object[]{
                    compra.getNotaFiscal(),
                    compra.getData(),
                    nomeFornecedor,
                    compra.getProduto().getDescricao(),
                    compra.getQuantidade(),
                    String.format(Locale.US, "R$ %.2f", compra.getValorCompra())
            });
        }
    }

    private void registrarNovaCompra() {
        DialogoCompra dialogo = new DialogoCompra((Frame) SwingUtilities.getWindowAncestor(this), cadastroFornecedores, cadastroProdutos);
        dialogo.setVisible(true);

        if (dialogo.isSalvo()) {
            cadastroCompras.inserirCompra(dialogo.getNovaCompra(), cadastroProdutos);
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Compra registrada e estoque atualizado com sucesso!");
        }
    }
}