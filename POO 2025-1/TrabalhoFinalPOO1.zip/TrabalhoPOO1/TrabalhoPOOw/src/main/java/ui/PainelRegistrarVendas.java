package ui;

import model.Cliente;
import model.Produto;
import model.Venda;
import service.CadastroClientes;
import service.CadastroCompras;
import service.CadastroProdutos;
import service.CadastroVendas;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Locale;

public class PainelRegistrarVendas extends JPanel {
    private final CadastroVendas cadastroVendas;
    private final CadastroClientes cadastroClientes;
    private final CadastroProdutos cadastroProdutos;

    private final JTable tabela;
    private final DefaultTableModel modeloTabela;

    public PainelRegistrarVendas(CadastroVendas cv, CadastroClientes cc, CadastroProdutos cp, ActionListener acaoVoltar) {
        this.cadastroVendas = cv;
        this.cadastroClientes = cc;
        this.cadastroProdutos = cp;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JLabel("Registro e Listagem de Vendas", SwingConstants.CENTER), BorderLayout.NORTH);

        String[] colunas = {"Data", "Cliente", "Produto", "Qtd", "Pagamento", "Valor Total"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(modeloTabela);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        JButton btnAdicionar = new JButton("Registrar Nova Venda");
        JButton btnVoltar = new JButton("Voltar");

        btnAdicionar.addActionListener(e -> registrarNovaVenda());
        btnVoltar.addActionListener(acaoVoltar);

        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnVoltar);
        add(painelBotoes, BorderLayout.SOUTH);

        this.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                atualizarTabela();
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {}
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {}
        });
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        for (Venda venda : cadastroVendas.getRelacaoVendas()) {
            Produto p = cadastroProdutos.buscarProduto(venda.getProduto());
            String nomeProduto = (p != null) ? p.getDescricao() : "Cód: " + venda.getProduto();

            String nomeCliente = "N/A";
            if (venda.getCliente() != 0) {
                Cliente c = cadastroClientes.getRelacaoClientes().stream()
                        .filter(cli -> cli.getId() == venda.getCliente())
                        .findFirst().orElse(null);
                nomeCliente = (c != null) ? c.getNome() : "ID: " + venda.getCliente();
            }

            modeloTabela.addRow(new Object[]{
                    venda.getData(),
                    nomeCliente,
                    nomeProduto,
                    venda.getQuantidade(),
                    venda.getPagamento(),
                    String.format(Locale.US, "R$ %.2f", venda.getValorVenda())
            });
        }
    }

    private void registrarNovaVenda() {
        DialogoVenda dialogo = new DialogoVenda((Frame) SwingUtilities.getWindowAncestor(this), cadastroProdutos, cadastroClientes);
        dialogo.setVisible(true);

        if (dialogo.isSalvo()) {
            try {
                cadastroVendas.inserirVenda(dialogo.getNovaVenda(), cadastroProdutos);
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Venda registrada e estoque atualizado com sucesso!");
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Erro na Venda", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}