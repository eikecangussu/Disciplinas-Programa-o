package ui;

import model.Produto;
import service.CadastroProdutos;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Locale;

public class PainelGerenciarProdutos extends JPanel {
    private final CadastroProdutos cadastroProdutos;
    private final JTable tabela;
    private final DefaultTableModel modeloTabela;

    public PainelGerenciarProdutos(CadastroProdutos cadastroProdutos, ActionListener acaoVoltar) {
        this.cadastroProdutos = cadastroProdutos;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JLabel("Gerenciamento de Produtos", SwingConstants.CENTER), BorderLayout.NORTH);

        String[] colunas = {"Código", "Descrição", "Estoque Atual", "Est. Mínimo", "Valor Custo", "Valor Venda"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(modeloTabela);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        JButton btnAdicionar = new JButton("Adicionar");
        JButton btnEditar = new JButton("Editar");
        JButton btnRemover = new JButton("Remover");
        JButton btnVoltar = new JButton("Voltar");

        btnAdicionar.addActionListener(e -> adicionarProduto());
        btnEditar.addActionListener(e -> editarProduto());
        btnRemover.addActionListener(e -> removerProduto());
        btnVoltar.addActionListener(acaoVoltar);

        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnRemover);
        painelBotoes.add(btnVoltar);
        add(painelBotoes, BorderLayout.SOUTH);

        this.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) { atualizarTabela(); }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {}
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {}
        });
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        for (Produto p : cadastroProdutos.getRelacaoProdutos()) {
            modeloTabela.addRow(new Object[]{
                    p.getCodigo(),
                    p.getDescricao(),
                    p.getEstoqueAtual(),
                    p.getEstoqueMinimo(),
                    String.format(Locale.US, "R$ %.2f", p.getValorCusto()),
                    String.format(Locale.US, "R$ %.2f", p.getPrecoVenda())
            });
        }
    }

    private void adicionarProduto() {
        DialogoProduto dialogo = new DialogoProduto((Frame) SwingUtilities.getWindowAncestor(this));
        dialogo.setVisible(true);
        if (dialogo.isSalvo()) {
            cadastroProdutos.inserirProduto(dialogo.getProdutoResultante());
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Produto adicionado com sucesso!");
        }
    }

    private void editarProduto() {
        int linhaSelecionada = tabela.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um produto para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        Produto produto = cadastroProdutos.buscarProduto(id);
        if (produto != null) {
            DialogoProduto dialogo = new DialogoProduto((Frame) SwingUtilities.getWindowAncestor(this), produto);
            dialogo.setVisible(true);
            if (dialogo.isSalvo()) {
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Produto atualizado com sucesso!");
            }
        }
    }

    private void removerProduto() {
        int linhaSelecionada = tabela.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um produto para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        int confirmacao = JOptionPane.showConfirmDialog(this, "Remover produto com código " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmacao == JOptionPane.YES_OPTION) {
            Produto produto = cadastroProdutos.buscarProduto(id);
            if (produto != null) {
                cadastroProdutos.getRelacaoProdutos().remove(produto);
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Produto removido com sucesso!");
            }
        }
    }
}