package ui;

import model.Fornecedor;
import javax.swing.*;
import java.awt.*;

public class DialogoFornecedor extends JDialog {
    private JTextField txtNomeEmpresa, txtEndereco, txtTelefone, txtCnpj, txtPessoaContato;
    private Fornecedor fornecedorResultante;
    private boolean salvo = false;

    public DialogoFornecedor(Frame owner) { this(owner, null); }
    public DialogoFornecedor(Frame owner, Fornecedor fornecedor) {
        super(owner, (fornecedor == null ? "Adicionar Fornecedor" : "Editar Fornecedor"), true);
        this.fornecedorResultante = fornecedor;
        setupUI();
        if (fornecedor != null) {
            preencherFormulario(fornecedor);
        }
    }

    private void setupUI() {
        setLayout(new BorderLayout());
        add(criarPainelFormulario(), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(getOwner());
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }

    private void preencherFormulario(Fornecedor f) {
        txtNomeEmpresa.setText(f.getNomeEmpresa());
        txtEndereco.setText(f.getEndereco());
        txtTelefone.setText(f.getTelefone());
        txtCnpj.setText(f.getCnpj());
        txtPessoaContato.setText(f.getPessoaDeContato());
    }

    private void salvar() {
        if (txtNomeEmpresa.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nome da empresa é obrigatório.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String nome = txtNomeEmpresa.getText();
        String end = txtEndereco.getText();
        String tel = txtTelefone.getText();
        String cnpj = txtCnpj.getText();
        String contato = txtPessoaContato.getText();

        if (fornecedorResultante == null) {
            fornecedorResultante = new Fornecedor(nome, end, tel, cnpj, contato);
        } else {
            fornecedorResultante.setNomeEmpresa(nome);
            fornecedorResultante.setEndereco(end);
            fornecedorResultante.setTelefone(tel);
            fornecedorResultante.setCnpj(cnpj);
            fornecedorResultante.setPessoaDeContato(contato);
        }
        salvo = true;
        dispose();
    }

    public Fornecedor getFornecedorResultante() { return fornecedorResultante; }
    public boolean isSalvo() { return salvo; }

    private JPanel criarPainelFormulario() {
        JPanel painel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridy = 0; gbc.gridx = 0; painel.add(new JLabel("Nome da Empresa:"), gbc);
        gbc.gridx = 1; txtNomeEmpresa = new JTextField(25); painel.add(txtNomeEmpresa, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Endereço:"), gbc);
        gbc.gridx = 1; txtEndereco = new JTextField(25); painel.add(txtEndereco, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Telefone:"), gbc);
        gbc.gridx = 1; txtTelefone = new JTextField(15); painel.add(txtTelefone, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("CNPJ:"), gbc);
        gbc.gridx = 1; txtCnpj = new JTextField(20); painel.add(txtCnpj, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Pessoa de Contato:"), gbc);
        gbc.gridx = 1; txtPessoaContato = new JTextField(25); painel.add(txtPessoaContato, gbc);
        return painel;
    }
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");
        btnSalvar.addActionListener(e -> salvar());
        btnCancelar.addActionListener(e -> dispose());
        painel.add(btnSalvar); painel.add(btnCancelar);
        return painel;
    }
}