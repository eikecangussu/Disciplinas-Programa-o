package ui;

import report.Relatorios;
import service.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.IOException;

public class PainelRelatorios extends JPanel {

    private final Relatorios relatorios;

    @FunctionalInterface
    private interface GeradorDeRelatorio {
        void gerar() throws IOException;
    }

    public PainelRelatorios(CadastroClientes cc, CadastroFornecedores cf, CadastroProdutos cp,
                            CadastroVendas cv, CadastroCompras ccomp, ActionListener acaoVoltar) {

        this.relatorios = new Relatorios(cc, cf, cp, cv.getRelacaoVendas(), ccomp.getRelacaoCompras());
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JLabel("Geração de Relatórios", SwingConstants.CENTER), BorderLayout.NORTH);

        JPanel painelBotoes = new JPanel(new GridLayout(3, 1, 10, 10));
        painelBotoes.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnTodosRelatorios = new JButton("Gerar TODOS os relatórios");
        JButton btnVoltar = new JButton("Voltar ao Menu");

        btnTodosRelatorios.addActionListener(e ->
                executarGeracao(relatorios::gerarTodosRelatorios, "Todos os Relatórios")
        );
        btnVoltar.addActionListener(acaoVoltar);

        painelBotoes.add(btnTodosRelatorios);
        add(painelBotoes, BorderLayout.CENTER);
        add(btnVoltar, BorderLayout.SOUTH);
    }

    private void executarGeracao(GeradorDeRelatorio gerador, String nomeRelatorio) {
        try {
            gerador.gerar();
            JOptionPane.showMessageDialog(this,
                    nomeRelatorio + " gerado(s) com sucesso!", "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao gerar " + nomeRelatorio + ": " + ex.getMessage(), "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}