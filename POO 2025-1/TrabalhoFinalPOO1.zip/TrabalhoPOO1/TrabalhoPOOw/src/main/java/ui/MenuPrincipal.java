package ui;

import model.*;
import report.Relatorios;
import service.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class MenuPrincipal {

    private final Scanner scanner;
    private final CadastroClientes cadastroClientes;
    private final CadastroFornecedores cadastroFornecedores;
    private final CadastroProdutos cadastroProdutos;
    private final CadastroVendas cadastroVendas;
    private final CadastroCompras cadastroCompras;

    public MenuPrincipal(CadastroClientes cc, CadastroFornecedores cf, CadastroProdutos cp, CadastroVendas cv, CadastroCompras ccomp) {
        this.scanner = new Scanner(System.in);
        this.cadastroClientes = cc;
        this.cadastroFornecedores = cf;
        this.cadastroProdutos = cp;
        this.cadastroVendas = cv;
        this.cadastroCompras = ccomp;
    }

    public void exibir() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- SISTEMA DE GESTÃO DA PADARIA ---");
            System.out.println("--- MENU PRINCIPAL ---");
            System.out.println("1. Gerenciar Cadastros");
            System.out.println("2. Registro de Vendas");
            System.out.println("3. Registro de Compras");
            System.out.println("4. Controle de Contas");
            System.out.println("5. Geração de Relatórios Mensais");
            System.out.println("0. Sair");
            System.out.print(">> Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());

                switch (opcao) {
                    case 1: menuGerenciarCadastros(); break;
                    case 2: menuRegistroVendas(); break;
                    case 3: menuRegistroCompras(); break;
                    case 4: menuControleContas(); break;
                    case 5: menuRelatorios(); break;
                    case 0: break;
                    default: System.out.println("Opção inválida! Tente novamente."); break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, digite um número válido.");
                opcao = -1;
            }
        }
    }

    private void menuGerenciarCadastros() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- MENU DE GERENCIAMENTO DE CADASTROS ---");
            System.out.println("1. Gerenciar Clientes");
            System.out.println("2. Gerenciar Fornecedores");
            System.out.println("3. Gerenciar Produtos");
            System.out.println("0. Voltar ao Menu Principal");
            System.out.print(">> Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
                switch (opcao) {
                    case 1:
                        submenuGerenciamento("Cliente",
                                this::cadastrarCliente,
                                this::listarClientes,
                                this::editarCliente,
                                this::buscarCliente,
                                this::removerCliente
                        );
                        break;
                    case 2:
                        submenuGerenciamento("Fornecedor",
                                this::cadastrarFornecedor,
                                this::listarFornecedores,
                                this::editarFornecedor,
                                this::buscarFornecedor,
                                this::removerFornecedor
                        );
                        break;
                    case 3:
                        submenuGerenciamento("Produto",
                                this::cadastrarProduto,
                                this::listarProdutos,
                                this::editarProduto,
                                this::buscarProduto,
                                this::removerProduto
                        );
                        break;
                    case 0: break;
                    default: System.out.println("Opção inválida!");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, digite um número válido.");
                opcao = -1;
            }
        }
    }

    private void submenuGerenciamento(String tipo, Runnable cadastrar, Runnable listar, Runnable editar, Runnable buscar, Runnable remover) {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- GERENCIAR " + tipo.toUpperCase() + "S ---");
            System.out.println("1. Cadastrar Novo " + tipo);
            System.out.println("2. Listar Todos");
            System.out.println("3. Editar " + tipo);
            System.out.println("4. Buscar " + tipo);
            System.out.println("5. Remover " + tipo);
            System.out.println("0. Voltar");
            System.out.print(">> Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
                switch (opcao) {
                    case 1: cadastrar.run(); break;
                    case 2: listar.run(); break;
                    case 3: editar.run(); break;
                    case 4: buscar.run(); break;
                    case 5: remover.run(); break;
                    case 0: break;
                    default: System.out.println("Opção inválida!");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, digite um número válido.");
                opcao = -1;
            }
        }
    }

    private void cadastrarCliente() {
        System.out.println("\n--- CADASTRO DE NOVO CLIENTE ---");
        System.out.print("Digite o tipo de cliente (F para Pessoa Física, J para Pessoa Jurídica): ");
        String tipoCliente = scanner.nextLine();

        if (!tipoCliente.equalsIgnoreCase("F") && !tipoCliente.equalsIgnoreCase("J")) {
            System.out.println("Tipo de cliente inválido!");
            return;
        }

        System.out.print("Nome: "); String nome = scanner.nextLine();
        System.out.print("Endereço: "); String endereco = scanner.nextLine();
        System.out.print("Telefone: "); String telefone = scanner.nextLine();
        String dtCadastro = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        if (tipoCliente.equalsIgnoreCase("F")) {
            System.out.print("CPF: "); String cpf = scanner.nextLine();
            ClientePF novoCliente = new ClientePF(nome, endereco, telefone, dtCadastro, "F", cpf);
            this.cadastroClientes.inserirCliente(novoCliente);
            System.out.println("\n>> Cliente Pessoa Física cadastrado com sucesso!");
        } else {
            System.out.print("CNPJ: "); String cnpj = scanner.nextLine();
            System.out.print("Inscrição Estadual: "); String inscEstadual = scanner.nextLine();
            ClientePJ novoCliente = new ClientePJ(cnpj, inscEstadual, nome, endereco, telefone, dtCadastro, "J");
            this.cadastroClientes.inserirCliente(novoCliente);
            System.out.println("\n>> Cliente Pessoa Jurídica cadastrado com sucesso!");
        }
    }

    private void listarClientes() {
        System.out.println("\n--- LISTA DE CLIENTES ---");
        List<Cliente> clientes = cadastroClientes.getRelacaoClientes();
        if (clientes.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
            return;
        }
        for (Cliente c : clientes) {
            System.out.printf("ID: %d, Nome: %s, Tipo: %s, Telefone: %s\n", c.getId(), c.getNome(), c.getTipo(), c.getTelefone());
        }
    }

    private void buscarCliente() {
        Cliente c = cadastroClientes.buscarClientePorId(scanner);
        if (c != null) {
            System.out.println("Cliente encontrado:");
            System.out.printf("ID: %s, Nome: %s, Tipo: %s, Endereço: %s, Telefone: %s\n", c.getId(), c.getNome(), c.getTipo(), c.getEndereco(), c.getTelefone());
        }
    }

    private void editarCliente() {
        System.out.println("\n--- EDITAR CLIENTE ---");
        Cliente c = cadastroClientes.buscarClientePorId(scanner);
        if (c != null) {
            System.out.print("Novo nome (deixe em branco para manter '"+c.getNome()+"'): ");
            String nome = scanner.nextLine(); if (!nome.isEmpty()) c.setNome(nome);

            System.out.print("Novo endereço (deixe em branco para manter '"+c.getEndereco()+"'): ");
            String endereco = scanner.nextLine(); if (!endereco.isEmpty()) c.setEndereco(endereco);

            System.out.print("Novo telefone (deixe em branco para manter '"+c.getTelefone()+"'): ");
            String telefone = scanner.nextLine(); if (!telefone.isEmpty()) c.setTelefone(telefone);

            System.out.println(">> Cliente atualizado com sucesso!");
        }
    }

    private void removerCliente() {
        System.out.println("\n--- REMOVER CLIENTE ---");
        Cliente c = cadastroClientes.buscarClientePorId(scanner);
        if (c != null) {
            cadastroClientes.getRelacaoClientes().remove(c);
            System.out.println(">> Cliente removido com sucesso!");
        }
    }

    private void cadastrarFornecedor() {
        System.out.println("\n--- CADASTRO DE NOVO FORNECEDOR ---");
        System.out.print("Nome da empresa: "); String nomeEmpresa = scanner.nextLine();
        System.out.print("Endereço: "); String endereco = scanner.nextLine();
        System.out.print("Telefone: "); String telefone = scanner.nextLine();
        System.out.print("CNPJ: "); String cnpj = scanner.nextLine();
        System.out.print("Pessoa de Contato: "); String pessoaDeContato = scanner.nextLine();
        Fornecedor novoFornecedor = new Fornecedor(nomeEmpresa, endereco, telefone, cnpj, pessoaDeContato);
        this.cadastroFornecedores.inserirFornecedor(novoFornecedor);
        System.out.println("\n>> Fornecedor cadastrado com sucesso!");
    }

    private void listarFornecedores() {
        System.out.println("\n--- LISTA DE FORNECEDORES ---");
        List<Fornecedor> fornecedores = cadastroFornecedores.getRelacaoFornecedores();
        if (fornecedores.isEmpty()) {
            System.out.println("Nenhum fornecedor cadastrado.");
            return;
        }
        for (Fornecedor f : fornecedores) {
            System.out.printf("ID: %d, Nome: %s, CNPJ: %s, Contato: %s\n", f.getId(), f.getNomeEmpresa(), f.getCnpj(), f.getPessoaDeContato());
        }
    }

    private void buscarFornecedor() {
        Fornecedor f = cadastroFornecedores.buscarFornecedorPorId(scanner);
        if (f != null) {
            System.out.println("Fornecedor encontrado:");
            System.out.printf("ID: %d, Nome: %s, CNPJ: %s, Endereço: %s\n", f.getId(), f.getNomeEmpresa(), f.getCnpj(), f.getEndereco());
        }
    }

    private void editarFornecedor() {
        System.out.println("\n--- EDITAR FORNECEDOR ---");
        Fornecedor f = cadastroFornecedores.buscarFornecedorPorId(scanner);
        if (f != null) {
            System.out.print("Novo nome da empresa (deixe em branco para manter '"+f.getNomeEmpresa()+"'): ");
            String nome = scanner.nextLine(); if (!nome.isEmpty()) f.setNomeEmpresa(nome);
            System.out.print("Novo contato (deixe em branco para manter '"+f.getPessoaDeContato()+"'): ");
            String contato = scanner.nextLine(); if (!contato.isEmpty()) f.setPessoaDeContato(contato);
            System.out.println(">> Fornecedor atualizado com sucesso!");
        }
    }

    private void removerFornecedor() {
        System.out.println("\n--- REMOVER FORNECEDOR ---");
        Fornecedor f = cadastroFornecedores.buscarFornecedorPorId(scanner);
        if (f != null) {
            cadastroFornecedores.getRelacaoFornecedores().remove(f);
            System.out.println(">> Fornecedor removido com sucesso!");
        }
    }

    private void cadastrarProduto() {
        System.out.println("\n--- CADASTRO DE NOVO PRODUTO ---");
        try {
            System.out.print("Descrição do produto: "); String descricao = scanner.nextLine();
            System.out.print("Estoque mínimo: "); int estoqueMinimo = Integer.parseInt(scanner.nextLine());
            System.out.print("Quantidade atual em estoque: "); int estoqueAtual = Integer.parseInt(scanner.nextLine());
            System.out.print("Valor de custo (use ponto, ex: 10.50): "); double valorCusto = Double.parseDouble(scanner.nextLine());
            System.out.print("Percentual de lucro (apenas o número, ex: 50): "); int percentualLucro = Integer.parseInt(scanner.nextLine());
            Produto novoProduto = new Produto(descricao, estoqueMinimo, estoqueAtual, valorCusto, percentualLucro);
            this.cadastroProdutos.inserirProduto(novoProduto);
            System.out.printf("\n>> Produto '%s' (Código: %d) cadastrado com sucesso!%n", novoProduto.getDescricao(), novoProduto.getCodigo());
        } catch (Exception e) {
            System.out.println("\nErro: " + e.getMessage() + " Cadastro cancelado.");
        }
    }

    private void listarProdutos() {
        System.out.println("\n--- LISTA DE PRODUTOS ---");
        List<Produto> produtos = cadastroProdutos.getRelacaoProdutos();
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }
        for (Produto p : produtos) {
            System.out.printf("Cód: %d, Descrição: %s, Estoque: %d, Preço Venda: R$ %.2f\n", p.getCodigo(), p.getDescricao(), p.getEstoqueAtual(), p.getPrecoVenda());
        }
    }

    private void buscarProduto() {
        Produto p = cadastroProdutos.buscarProdutoPorId(scanner);
        if (p != null) {
            System.out.println("Produto encontrado:");
            System.out.printf("Cód: %d, Descrição: %s, Estoque: %d/%d, Custo: R$ %.2f, Venda: R$ %.2f\n", p.getCodigo(), p.getDescricao(), p.getEstoqueAtual(), p.getEstoqueMinimo(), p.getValorCusto(), p.getPrecoVenda());
        }
    }

    private void editarProduto() {
        System.out.println("\n--- EDITAR PRODUTO (ATUALIZAR ESTOQUE) ---");
        Produto p = cadastroProdutos.buscarProdutoPorId(scanner);
        if (p != null) {
            try {
                System.out.print("Nova quantidade em estoque (deixe em branco para manter '"+p.getEstoqueAtual()+"'): ");
                String estoqueStr = scanner.nextLine();
                if (!estoqueStr.isEmpty()) {
                    int novoEstoque = Integer.parseInt(estoqueStr);
                    p.setEstoqueAtual(novoEstoque);
                    System.out.println(">> Estoque atualizado com sucesso!");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
    }

    private void removerProduto() {
        System.out.println("\n--- REMOVER PRODUTO ---");
        Produto p = cadastroProdutos.buscarProdutoPorId(scanner);
        if (p != null) {
            cadastroProdutos.getRelacaoProdutos().remove(p);
            System.out.println(">> Produto removido com sucesso!");
        }
    }

    private void menuRegistroVendas() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- MENU DE REGISTRO DE VENDAS ---");
            System.out.println("1. Registrar Nova Venda");
            System.out.println("2. Listar Todas as Vendas");
            System.out.println("0. Voltar ao Menu Principal");
            System.out.print(">> Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
                switch (opcao) {
                    case 1: registrarVenda(); break;
                    case 2: listarVendas(); break;
                    case 0: break;
                    default: System.out.println("Opção inválida!");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, digite um número válido.");
                opcao = -1;
            }
        }
    }

    private void registrarVenda() {
        System.out.println("\n--- REGISTRAR NOVA VENDA ---");
        try {
            System.out.println("\nProdutos disponíveis:");
            listarProdutos();
            Produto produto = cadastroProdutos.buscarProdutoPorId(scanner);
            if (produto == null) return;

            System.out.print("Quantidade vendida: ");
            int quantidade = Integer.parseInt(scanner.nextLine());
            if (quantidade > produto.getEstoqueAtual()) {
                System.out.println("ERRO: Estoque insuficiente. Operação cancelada.");
                return;
            }

            System.out.print("Modo de Pagamento ($, X, D, C, T, F): ");
            String pagamento = scanner.nextLine();

            int clienteId = 0;
            if (pagamento.equalsIgnoreCase("F")) {
                System.out.println("\nClientes disponíveis:");
                listarClientes();
                Cliente cliente = cadastroClientes.buscarClientePorId(scanner);
                if (cliente == null) return;
                clienteId = cliente.getId();
            }

            String data = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            Venda novaVenda = new Venda(clienteId, data, produto.getCodigo(), quantidade, pagamento, cadastroProdutos);
            cadastroVendas.inserirVenda(novaVenda);
            produto.setEstoqueAtual(produto.getEstoqueAtual() - quantidade);
            System.out.println(">> Venda registrada com sucesso! Estoque atualizado.");
        } catch (NumberFormatException e) {
            System.out.println("Erro: Quantidade inválida. Operação cancelada.");
        }
    }

    private void listarVendas() {
        System.out.println("\n--- LISTA DE VENDAS ---");
        List<Venda> vendas = cadastroVendas.getRelacaoVendas();
        if (vendas.isEmpty()) {
            System.out.println("Nenhuma venda registrada.");
            return;
        }
        for (Venda v : vendas) {
            String clienteInfo = (v.getCliente() != 0) ? "Cliente ID: " + v.getCliente() : "À Vista";
            System.out.printf("Data: %s, Produto Cód: %s, Qtd: %d, Pgto: %s, %s\n", v.getData(), v.getProduto(), v.getQuantidade(), v.getPagamento(), clienteInfo);
        }
    }

    private void menuRegistroCompras() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- MENU DE REGISTRO DE COMPRAS ---");
            System.out.println("1. Registrar Nova Compra");
            System.out.println("2. Listar Todas as Compras");
            System.out.println("0. Voltar ao Menu Principal");
            System.out.print(">> Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
                switch (opcao) {
                    case 1: registrarCompra(); break;
                    case 2: listarContasAPagar(); break;
                    case 0: break;
                    default: System.out.println("Opção inválida!");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, digite um número válido.");
                opcao = -1;
            }
        }
    }

    private void registrarCompra() {
        System.out.println("\n--- REGISTRAR NOVA COMPRA ---");
        try {
            System.out.print("Número da Nota Fiscal: ");
            int notaFiscal = Integer.parseInt(scanner.nextLine());

            System.out.println("\nFornecedores disponíveis:");
            listarFornecedores();
            Fornecedor fornecedor = cadastroFornecedores.buscarFornecedorPorId(scanner);
            if (fornecedor == null) return;

            System.out.println("\nProdutos disponíveis:");
            listarProdutos();
            Produto produto = cadastroProdutos.buscarProdutoPorId(scanner);
            if (produto == null) return;

            System.out.print("Quantidade comprada: ");
            int quantidade = Integer.parseInt(scanner.nextLine());
            if (quantidade <= 0) {
                System.out.println("ERRO: A quantidade deve ser positiva.");
                return;
            }

            String data = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            Compra novaCompra = new Compra(notaFiscal, fornecedor.getId(), data, produto, quantidade);
            cadastroCompras.inserirCompra(novaCompra, cadastroProdutos);

            System.out.println("\n>> Compra registrada com sucesso!");
            System.out.printf("   Produto '%s' teve seu estoque atualizado para %d unidades.%n",
                    produto.getDescricao(), produto.getEstoqueAtual());
        } catch (NumberFormatException e) {
            System.out.println("ERRO: Número inválido. Operação cancelada.");
        }
    }

    private void menuControleContas() {
        System.out.println("\n--- CONTROLE DE CONTAS ---");
        System.out.println("\n--- CONTAS A PAGAR (COMPRAS REGISTRADAS) ---");
        listarContasAPagar();
        System.out.println("\n--- CONTAS A RECEBER (VENDAS FIADO) ---");
        listarContasAReceber();
    }

    private void listarContasAPagar() {
        List<Compra> compras = cadastroCompras.getRelacaoCompras();
        if (compras.isEmpty()) {
            System.out.println("Nenhuma compra registrada.");
            return;
        }
        for (Compra c : compras) {
            Fornecedor f = cadastroFornecedores.buscarFornecedor(c.getFornecedor());
            String nomeFornecedor = (f != null) ? f.getNomeEmpresa() : "ID " + c.getFornecedor();
            System.out.printf("NF: %d, Data: %s, Fornecedor: %s, Produto: %s, Valor: R$ %.2f\n",
                    c.getNotaFiscal(), c.getData(), nomeFornecedor, c.getProduto().getDescricao(), c.getValorCompra());
        }
    }

    private void listarContasAReceber() {
        List<Venda> fiados = cadastroVendas.gerarFiados();
        if (fiados.isEmpty()) {
            System.out.println("Nenhuma venda a prazo (fiado) registrada.");
            return;
        }
        for (Venda v : fiados) {
            System.out.printf("Data: %s, Cliente ID: %s, Produto Cód: %s, Qtd: %d, Valor: R$ %.2f\n",
                    v.getData(), v.getCliente(), v.getProduto(), v.getQuantidade(), v.getValorVenda());
        }
    }

    private void menuRelatorios() {
        Relatorios relatorios = new Relatorios(
                cadastroClientes,
                cadastroFornecedores,
                cadastroProdutos,
                cadastroVendas.getRelacaoVendas(),
                cadastroCompras.getRelacaoCompras()
        );
        relatorios.gerarTodosRelatorios();
        System.out.println("\n>> Todos os relatórios foram gerados com sucesso na raiz do projeto!");
    }
}