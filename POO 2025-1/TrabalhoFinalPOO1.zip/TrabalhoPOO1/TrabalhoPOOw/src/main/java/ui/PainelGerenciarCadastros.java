package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PainelGerenciarCadastros extends JPanel {

    public PainelGerenciarCadastros(ActionListener acaoClientes, ActionListener acaoFornecedores, ActionListener acaoProdutos, ActionListener acaoVoltar) {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JLabel("Gerenciamento de Cadastros", SwingConstants.CENTER), BorderLayout.NORTH);

        JPanel painelBotoes = new JPanel(new GridLayout(3, 1, 10, 10));
        painelBotoes.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnClientes = new JButton("Gerenciar Clientes");
        JButton btnFornecedores = new JButton("Gerenciar Fornecedores");
        JButton btnProdutos = new JButton("Gerenciar Produtos");
        JButton btnVoltar = new JButton("Voltar ao Menu Principal");

        btnClientes.addActionListener(acaoClientes);
        btnFornecedores.addActionListener(acaoFornecedores);
        btnProdutos.addActionListener(acaoProdutos);
        btnVoltar.addActionListener(acaoVoltar);

        painelBotoes.add(btnClientes);
        painelBotoes.add(btnFornecedores);
        painelBotoes.add(btnProdutos);

        add(painelBotoes, BorderLayout.CENTER);
        add(btnVoltar, BorderLayout.SOUTH);
    }
}