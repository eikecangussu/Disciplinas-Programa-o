package ui;

import model.*;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DialogoCliente extends JDialog {
    private JTextField txtNome, txtEndereco, txtTelefone;
    private JTextField txtCpf, txtCnpj, txtInscEstadual;
    private JRadioButton rdbPessoaFisica, rdbPessoaJuridica;
    private JPanel painelPessoaFisica, painelPessoaJuridica;
    private Cliente clienteResultante = null;
    private boolean salvo = false;

    public DialogoCliente(Frame owner) { this(owner, null); }
    public DialogoCliente(Frame owner, Cliente cliente) {
        super(owner, (cliente == null ? "Adicionar Cliente" : "Editar Cliente"), true);
        this.clienteResultante = cliente;
        setupUI();
        if (cliente != null) {
            preencherFormulario(cliente);
        }
    }

    private void setupUI() {
        setLayout(new BorderLayout());
        add(criarPainelFormulario(), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(getOwner());
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }

    private void preencherFormulario(Cliente c) {
        txtNome.setText(c.getNome());
        txtEndereco.setText(c.getEndereco());
        txtTelefone.setText(c.getTelefone());
        if (c instanceof ClientePF) {
            rdbPessoaFisica.setSelected(true);
            txtCpf.setText(((ClientePF) c).getCpf());
        } else {
            rdbPessoaJuridica.setSelected(true);
            txtCnpj.setText(((model.ClientePJ) c).getCnpj());
            txtInscEstadual.setText(((model.ClientePJ) c).getInscEstadual());
        }
        rdbPessoaFisica.setEnabled(false);
        rdbPessoaJuridica.setEnabled(false);
        alternarPaineis(c instanceof ClientePF);
    }

    private void salvar() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nome é obrigatório.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String nome = txtNome.getText();
        String endereco = txtEndereco.getText();
        String telefone = txtTelefone.getText();

        if (clienteResultante == null) {
            String dt = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            if (rdbPessoaFisica.isSelected()) {
                clienteResultante = new ClientePF(nome, endereco, telefone, dt, "F", txtCpf.getText());
            } else {
                clienteResultante = new ClientePJ(txtCnpj.getText(), txtInscEstadual.getText(), nome, endereco, telefone, dt, "J");
            }
        } else { // Editar
            clienteResultante.setNome(nome);
            clienteResultante.setEndereco(endereco);
            clienteResultante.setTelefone(telefone);
            if (clienteResultante instanceof ClientePF) {
                ((ClientePF) clienteResultante).setCpf(txtCpf.getText());
            } else {
                ((model.ClientePJ) clienteResultante).setCnpj(txtCnpj.getText());
                ((model.ClientePJ) clienteResultante).setInscEstadual(txtInscEstadual.getText());
            }
        }
        salvo = true;
        dispose();
    }

    public Cliente getClienteResultante() { return clienteResultante; }
    public boolean isSalvo() { return salvo; }

    private void alternarPaineis(boolean isPF) {
        painelPessoaFisica.setVisible(isPF);
        painelPessoaJuridica.setVisible(!isPF);
        pack();
    }

    private JPanel criarPainelFormulario() {
        JPanel painel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridy = 0; gbc.gridx = 0; painel.add(new JLabel("Nome:"), gbc);
        gbc.gridx = 1; txtNome = new JTextField(20); painel.add(txtNome, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Endereço:"), gbc);
        gbc.gridx = 1; txtEndereco = new JTextField(20); painel.add(txtEndereco, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Telefone:"), gbc);
        gbc.gridx = 1; txtTelefone = new JTextField(15); painel.add(txtTelefone, gbc);
        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Tipo:"), gbc);
        rdbPessoaFisica = new JRadioButton("Pessoa Física", true);
        rdbPessoaJuridica = new JRadioButton("Pessoa Jurídica");
        ButtonGroup grupo = new ButtonGroup(); grupo.add(rdbPessoaFisica); grupo.add(rdbPessoaJuridica);
        JPanel painelRadio = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelRadio.add(rdbPessoaFisica); painelRadio.add(rdbPessoaJuridica);
        gbc.gridx = 1; painel.add(painelRadio, gbc);
        criarPaineisTipoPessoa();
        gbc.gridy++; gbc.gridx = 0; gbc.gridwidth = 2;
        painel.add(painelPessoaFisica, gbc); painel.add(painelPessoaJuridica, gbc);
        rdbPessoaFisica.addActionListener(e -> alternarPaineis(true));
        rdbPessoaJuridica.addActionListener(e -> alternarPaineis(false));
        alternarPaineis(true);
        return painel;
    }
    private void criarPaineisTipoPessoa() {
        painelPessoaFisica = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelPessoaFisica.add(new JLabel("CPF:"));
        txtCpf = new JTextField(15); painelPessoaFisica.add(txtCpf);
        painelPessoaJuridica = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelPessoaJuridica.add(new JLabel("CNPJ:"));
        txtCnpj = new JTextField(18); painelPessoaJuridica.add(txtCnpj);
        painelPessoaJuridica.add(new JLabel("Insc. Estadual:"));
        txtInscEstadual = new JTextField(15); painelPessoaJuridica.add(txtInscEstadual);
    }
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");
        btnSalvar.addActionListener(e -> salvar());
        btnCancelar.addActionListener(e -> dispose());
        painel.add(btnSalvar); painel.add(btnCancelar);
        return painel;
    }
}