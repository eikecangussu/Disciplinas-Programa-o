package ui;

import model.*;
import service.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Locale;

public class PainelControleContas extends JPanel {

    private final CadastroClientes cadastroClientes;
    private final CadastroFornecedores cadastroFornecedores;
    private final CadastroVendas cadastroVendas;
    private final CadastroCompras cadastroCompras;

    private DefaultTableModel modeloTabelaPagar;
    private DefaultTableModel modeloTabelaReceber;

    public PainelControleContas(CadastroClientes cc, CadastroFornecedores cf, CadastroVendas cv, CadastroCompras ccomp, ActionListener acaoVoltar) {
        this.cadastroClientes = cc;
        this.cadastroFornecedores = cf;
        this.cadastroVendas = cv;
        this.cadastroCompras = ccomp;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JLabel("Controle de Contas", SwingConstants.CENTER), BorderLayout.NORTH);

        JTabbedPane abas = new JTabbedPane();
        abas.addTab("Contas a Pagar", criarPainelContasPagar());
        abas.addTab("Contas a Receber", criarPainelContasReceber());

        add(abas, BorderLayout.CENTER);

        JButton btnVoltar = new JButton("Voltar ao Menu");
        btnVoltar.addActionListener(acaoVoltar);
        add(btnVoltar, BorderLayout.SOUTH);

        abas.addChangeListener(e -> {
            if (abas.getSelectedIndex() == 0) {
                atualizarTabelaPagar();
            } else if (abas.getSelectedIndex() == 1) {
                atualizarTabelaReceber();
            }
        });

        this.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                atualizarTabelaPagar();
                atualizarTabelaReceber();
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {}
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {}
        });
    }

    private JScrollPane criarPainelContasPagar() {
        String[] colunas = {"Fornecedor", "CNPJ", "Contato", "Telefone", "Valor a Pagar"};
        modeloTabelaPagar = new DefaultTableModel(colunas, 0);
        JTable tabelaContasPagar = new JTable(modeloTabelaPagar);
        return new JScrollPane(tabelaContasPagar);
    }

    private JScrollPane criarPainelContasReceber() {
        String[] colunas = {"Cliente", "Tipo", "CPF/CNPJ", "Telefone", "Valor a Receber"};
        modeloTabelaReceber = new DefaultTableModel(colunas, 0);
        JTable tabelaContasReceber = new JTable(modeloTabelaReceber);
        return new JScrollPane(tabelaContasReceber);
    }

    private void atualizarTabelaPagar() {
        modeloTabelaPagar.setRowCount(0);
        for (Fornecedor f : cadastroFornecedores.getRelacaoFornecedores()) {
            double total = cadastroCompras.getRelacaoCompras().stream()
                    .filter(c -> c.getFornecedor() == f.getId())
                    .mapToDouble(Compra::getValorCompra).sum();
            if (total > 0) {
                modeloTabelaPagar.addRow(new Object[]{
                        f.getNomeEmpresa(), f.getCnpj(), f.getPessoaDeContato(), f.getTelefone(),
                        String.format(Locale.US, "R$ %.2f", total)
                });
            }
        }
    }

    private void atualizarTabelaReceber() {
        modeloTabelaReceber.setRowCount(0);
        for (Cliente c : cadastroClientes.getRelacaoClientes()) {
            double total = cadastroVendas.gerarFiados().stream()
                    .filter(v -> v.getCliente() == c.getId())
                    .mapToDouble(Venda::getValorVenda).sum();
            if (total > 0) {
                String documento = (c instanceof ClientePF) ? ((ClientePF) c).getCpf() : ((model.ClientePJ) c).getCnpj();
                modeloTabelaReceber.addRow(new Object[]{
                        c.getNome(), c.getTipo(), documento, c.getTelefone(),
                        String.format(Locale.US, "R$ %.2f", total)
                });
            }
        }
    }
}