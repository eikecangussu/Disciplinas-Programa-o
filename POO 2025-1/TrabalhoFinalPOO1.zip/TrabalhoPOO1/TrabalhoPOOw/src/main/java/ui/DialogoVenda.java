package ui;

import model.Cliente;
import model.Produto;
import model.Venda;
import service.CadastroClientes;
import service.CadastroProdutos;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

public class DialogoVenda extends JDialog {
    private JComboBox<Produto> cmbProduto;
    private JSpinner spnQuantidade;
    private JComboBox<String> cmbPagamento;
    private JComboBox<Cliente> cmbCliente;

    private Venda novaVenda = null;
    private boolean salvo = false;

    private final CadastroProdutos cadastroProdutos;

    public DialogoVenda(Frame owner, CadastroProdutos cadProdutos, CadastroClientes cadClientes) {
        super(owner, "Registrar Nova Venda", true);
        this.cadastroProdutos = cadProdutos;
        setLayout(new BorderLayout(10, 10));

        Vector<Produto> produtos = new Vector<>(cadProdutos.getRelacaoProdutos());
        Vector<Cliente> clientes = new Vector<>(cadClientes.getRelacaoClientes());
        Vector<String> pagamentos = new Vector<>(java.util.List.of("$", "X", "D", "C", "T", "F"));

        if (produtos.isEmpty()) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(owner, "É necessário ter ao menos um produto cadastrado para registrar uma venda.", "Cadastro Incompleto", JOptionPane.WARNING_MESSAGE);
                dispose();
            });
            return;
        }

        cmbProduto = new JComboBox<>(produtos);
        spnQuantidade = new JSpinner(new SpinnerNumberModel(1, 1, 9999, 1));
        cmbPagamento = new JComboBox<>(pagamentos);
        cmbCliente = new JComboBox<>(clientes);

        cmbCliente.setEnabled(false);
        cmbPagamento.addActionListener(e -> {
            boolean isFiado = "F".equals(cmbPagamento.getSelectedItem());
            cmbCliente.setEnabled(isFiado);
        });

        add(criarPainelFormulario(), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }

    private JPanel criarPainelFormulario() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        gbc.gridy = 0; gbc.gridx = 0; painel.add(new JLabel("Produto:"), gbc);
        gbc.gridx = 1; painel.add(cmbProduto, gbc);

        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Quantidade:"), gbc);
        gbc.gridx = 1; painel.add(spnQuantidade, gbc);

        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Forma de Pagamento:"), gbc);
        gbc.gridx = 1; painel.add(cmbPagamento, gbc);

        gbc.gridy++; gbc.gridx = 0; painel.add(new JLabel("Cliente (se Fiado):"), gbc);
        gbc.gridx = 1; painel.add(cmbCliente, gbc);

        return painel;
    }

    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSalvar = new JButton("Salvar");
        JButton btnCancelar = new JButton("Cancelar");
        btnSalvar.addActionListener(e -> salvar());
        btnCancelar.addActionListener(e -> dispose());
        painel.add(btnSalvar);
        painel.add(btnCancelar);
        return painel;
    }

    private void salvar() {
        Produto produto = (Produto) cmbProduto.getSelectedItem();
        int quantidade = (int) spnQuantidade.getValue();

        if (produto == null) {
            JOptionPane.showMessageDialog(this, "Selecione um produto.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (produto.getEstoqueAtual() < quantidade) {
            JOptionPane.showMessageDialog(this,
                    "Estoque insuficiente! Estoque atual: " + produto.getEstoqueAtual(),
                    "Erro de Estoque", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String pagamento = (String) cmbPagamento.getSelectedItem();
        int clienteId = 0;

        if ("F".equals(pagamento)) {
            Cliente cliente = (Cliente) cmbCliente.getSelectedItem();
            if (cliente == null) {
                JOptionPane.showMessageDialog(this, "Para venda fiado, um cliente deve ser selecionado.", "Erro de Validação", JOptionPane.ERROR_MESSAGE);
                return;
            }
            clienteId = cliente.getId();
        }

        String data = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        this.novaVenda = new Venda(clienteId, data, produto.getCodigo(), quantidade, pagamento, cadastroProdutos);
        this.salvo = true;
        dispose();
    }

    public Venda getNovaVenda() { return novaVenda; }
    public boolean isSalvo() { return salvo; }
}