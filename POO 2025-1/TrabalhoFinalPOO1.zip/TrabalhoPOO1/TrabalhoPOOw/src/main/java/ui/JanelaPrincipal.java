package ui;

import io.EscritorDados;
import io.EscritorRelatorios;
import service.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class JanelaPrincipal extends JFrame {

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel painelPrincipal = new JPanel(cardLayout);

    public JanelaPrincipal(CadastroClientes cc, CadastroFornecedores cf, CadastroProdutos cp,
                           CadastroVendas cv, CadastroCompras ccomp, String[] arquivos) {

        setTitle("Sistema de Gestão de Padaria");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel painelMenuPrincipal = new JPanel(new GridLayout(6, 1, 10, 10));
        painelMenuPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnGerenciarCadastros = new JButton("Gerenciar Cadastros");
        JButton btnRegistroVendas = new JButton("Registro de Vendas");
        JButton btnRegistroCompras = new JButton("Registro de Compras");
        JButton btnControleContas = new JButton("Controle de Contas");
        JButton btnGerarRelatorios = new JButton("Geração de Relatórios");
        JButton btnSair = new JButton("Sair e Salvar");

        painelMenuPrincipal.add(btnGerenciarCadastros);
        painelMenuPrincipal.add(btnRegistroVendas);
        painelMenuPrincipal.add(btnRegistroCompras);
        painelMenuPrincipal.add(btnControleContas);
        painelMenuPrincipal.add(btnGerarRelatorios);
        painelMenuPrincipal.add(btnSair);

        ActionListener acaoVoltarParaMenu = e -> cardLayout.show(painelPrincipal, "MENU");
        ActionListener acaoMostrarClientes = e -> cardLayout.show(painelPrincipal, "CLIENTES");
        ActionListener acaoMostrarFornecedores = e -> cardLayout.show(painelPrincipal, "FORNECEDORES");
        ActionListener acaoMostrarProdutos = e -> cardLayout.show(painelPrincipal, "PRODUTOS");
        ActionListener acaoVoltarParaCadastros = e -> cardLayout.show(painelPrincipal, "CADASTROS_MENU");

        PainelGerenciarCadastros painelCadastros = new PainelGerenciarCadastros(acaoMostrarClientes, acaoMostrarFornecedores, acaoMostrarProdutos, acaoVoltarParaMenu);
        PainelGerenciarClientes painelClientes = new PainelGerenciarClientes(cc, acaoVoltarParaCadastros);
        PainelGerenciarFornecedores painelFornecedores = new PainelGerenciarFornecedores(cf, acaoVoltarParaCadastros);
        PainelGerenciarProdutos painelProdutos = new PainelGerenciarProdutos(cp, acaoVoltarParaCadastros);
        PainelRegistrarCompras painelCompras = new PainelRegistrarCompras(ccomp, cf, cp, acaoVoltarParaMenu);
        PainelControleContas painelContas = new PainelControleContas(cc, cf, cv, ccomp, acaoVoltarParaMenu);
        PainelRelatorios painelRelatorios = new PainelRelatorios(cc, cf, cp, cv, ccomp, acaoVoltarParaMenu);

        PainelRegistrarVendas painelVendas = new PainelRegistrarVendas(cv, cc, cp, acaoVoltarParaMenu);

        painelPrincipal.add(painelMenuPrincipal, "MENU");
        painelPrincipal.add(painelCadastros, "CADASTROS_MENU");
        painelPrincipal.add(painelClientes, "CLIENTES");
        painelPrincipal.add(painelFornecedores, "FORNECEDORES");
        painelPrincipal.add(painelProdutos, "PRODUTOS");
        painelPrincipal.add(painelVendas, "VENDAS"); // Agora usa o painel real
        painelPrincipal.add(painelCompras, "COMPRAS");
        painelPrincipal.add(painelContas, "CONTAS");
        painelPrincipal.add(painelRelatorios, "RELATORIOS");

        add(painelPrincipal);

        btnGerenciarCadastros.addActionListener(e -> cardLayout.show(painelPrincipal, "CADASTROS_MENU"));
        btnRegistroVendas.addActionListener(e -> cardLayout.show(painelPrincipal, "VENDAS"));
        btnRegistroCompras.addActionListener(e -> cardLayout.show(painelPrincipal, "COMPRAS"));
        btnControleContas.addActionListener(e -> cardLayout.show(painelPrincipal, "CONTAS"));
        btnGerarRelatorios.addActionListener(e -> cardLayout.show(painelPrincipal, "RELATORIOS"));

        btnSair.addActionListener(e -> {
            try {
                EscritorDados.salvarClientes(arquivos[0], cc.getRelacaoClientes());
                EscritorDados.salvarFornecedores(arquivos[1], cf.getRelacaoFornecedores());
                EscritorDados.salvarProdutos(arquivos[2], cp.getRelacaoProdutos());
                EscritorRelatorios.salvarCompras(arquivos[3], ccomp.getRelacaoCompras());
                EscritorRelatorios.salvarVendas(arquivos[4], cv.getRelacaoVendas());
                JOptionPane.showMessageDialog(null, "Dados salvos com sucesso!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Erro ao salvar os dados: " + ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
            System.exit(0);
        });
    }
}