package ui;

import model.Cliente;
import model.ClientePF;
import service.CadastroClientes;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

public class PainelGerenciarClientes extends JPanel {
    private final CadastroClientes cadastroClientes;
    private final JTable tabela;
    private final DefaultTableModel modeloTabela;

    public PainelGerenciarClientes(CadastroClientes cadastroClientes, ActionListener acaoVoltar) {
        this.cadastroClientes = cadastroClientes;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JLabel("Gerenciamento de Clientes", SwingConstants.CENTER), BorderLayout.NORTH);

        String[] colunas = {"ID", "Nome", "Tipo", "CPF/CNPJ", "Telefone"};
        modeloTabela = new DefaultTableModel(colunas, 0){
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(modeloTabela);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        JButton btnAdicionar = new JButton("Adicionar");
        JButton btnEditar = new JButton("Editar");
        JButton btnRemover = new JButton("Remover");
        JButton btnVoltar = new JButton("Voltar");

        btnAdicionar.addActionListener(e -> adicionarCliente());
        btnEditar.addActionListener(e -> editarCliente());
        btnRemover.addActionListener(e -> removerCliente());
        btnVoltar.addActionListener(acaoVoltar);

        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnRemover);
        painelBotoes.add(btnVoltar);

        add(painelBotoes, BorderLayout.SOUTH);

        this.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) { atualizarTabela(); }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {}
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {}
        });
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        for (Cliente cliente : cadastroClientes.getRelacaoClientes()) {
            String doc = (cliente instanceof ClientePF) ? ((ClientePF) cliente).getCpf() : ((model.ClientePJ) cliente).getCnpj();
            modeloTabela.addRow(new Object[]{
                    cliente.getId(), cliente.getNome(), cliente.getTipo(), doc, cliente.getTelefone()
            });
        }
    }

    private void adicionarCliente() {
        DialogoCliente dialogo = new DialogoCliente((Frame) SwingUtilities.getWindowAncestor(this));
        dialogo.setVisible(true);
        Cliente clienteCriado = dialogo.getClienteResultante();
        if (dialogo.isSalvo()) {
            cadastroClientes.inserirCliente(clienteCriado);
            atualizarTabela();
            JOptionPane.showMessageDialog(this, "Cliente adicionado com sucesso!");
        }
    }

    private void editarCliente() {
        int linhaSelecionada = tabela.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um cliente para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int idCliente = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        Cliente clienteParaEditar = cadastroClientes.getRelacaoClientes().stream()
                .filter(c -> c.getId() == idCliente).findFirst().orElse(null);

        if (clienteParaEditar != null) {
            DialogoCliente dialogo = new DialogoCliente((Frame) SwingUtilities.getWindowAncestor(this), clienteParaEditar);
            dialogo.setVisible(true);
            if (dialogo.isSalvo()) {
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Cliente atualizado com sucesso!");
            }
        }
    }

    private void removerCliente() {
        int linhaSelecionada = tabela.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um cliente para remover.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int idCliente = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        int confirmacao = JOptionPane.showConfirmDialog(this, "Remover cliente com ID " + idCliente + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmacao == JOptionPane.YES_OPTION) {
            Cliente clienteARemover = cadastroClientes.getRelacaoClientes().stream()
                    .filter(c -> c.getId() == idCliente).findFirst().orElse(null);
            if (clienteARemover != null) {
                cadastroClientes.getRelacaoClientes().remove(clienteARemover);
                atualizarTabela();
                JOptionPane.showMessageDialog(this, "Cliente removido com sucesso!");
            }
        }
    }
}