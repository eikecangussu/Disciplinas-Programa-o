package com.mycompany.lab07_ek;


public class Quadrado implements Forma2D {
    
    private double lado;
    private double area;

    public Quadrado(double lado) {
        this.lado = lado;
    }

    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }
    
    @Override
    public double calcularArea() {
        this.area = this.lado*this.lado;
        return this.area;
    }

    @Override
    public void imprimirDados() {
        System.out.println("Quadrado");
        System.out.println("Lado : "+this.lado);
        System.out.println("Area : "+calcularArea());
        System.out.println();
    }
    
}
