package com.mycompany.lab07_ek;


public class Cubo implements Forma3D {
    
    private double lado;
    private double area;
    private double volume;

    public Cubo(double lado) {
        this.lado = lado;
    }

    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }

    @Override
    public double calcularVolume() {
        this.volume = this.lado*this.lado*this.lado;
        return this.volume;
    }

    @Override
    public double calcularArea() {
        this.area = ((this.lado*this.lado)*6);
        return this.area;
    }

    @Override
    public void imprimirDados() {
        System.out.println("Cubo");
        System.out.println("Lado : "+this.lado);
        System.out.println("Area : "+calcularArea());
        System.out.println("Volume : "+calcularVolume());
        System.out.println();
    }
    
}
