package com.mycompany.lab07_ek;

public class Circulo implements Forma2D {
    
    private double raio;
    private double area;

    public Circulo(double raio) {
        this.raio = raio;
    }

    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }
    
    @Override
    public double calcularArea() {
        this.area = (Math.pow(raio, 2))*Math.PI;
        return this.area;
    }

    @Override
    public void imprimirDados() {
        System.out.println("Circulo");
        System.out.println("Raio : "+this.raio);
        System.out.println("Area : "+calcularArea());
        System.out.println();
    }
    
}
