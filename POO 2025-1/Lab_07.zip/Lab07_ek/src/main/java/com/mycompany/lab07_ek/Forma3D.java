package com.mycompany.lab07_ek;

public interface Forma3D extends Forma {
    double calcularVolume();
}
