package com.mycompany.lab07_ek;


public class Cilindro implements Forma3D {
    
    private double raio;
    private double altura;
    private double area;
    private double volume;

    public Cilindro(double raio, double altura) {
        this.raio = raio;
        this.altura = altura;
    }

    public double getRaio() {
        return raio;
    }

    public double getAltura() {
        return altura;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public double calcularVolume() {
        this.volume = Math.PI*Math.pow(raio, 2)*this.altura;
        return this.volume;
    }

    @Override
    public double calcularArea() {
        this.area = 2*(((Math.PI)*Math.pow(raio, 2))+(Math.PI*this.raio*this.altura));
        return this.area;
    }

    @Override
    public void imprimirDados() {
        System.out.println("Cilindro");
        System.out.println("Raio : "+this.raio);
        System.out.println("Altura : "+this.altura);
        System.out.println("Area : "+calcularArea());
        System.out.println("Volume : "+calcularVolume());
        System.out.println();
    }
    
}
