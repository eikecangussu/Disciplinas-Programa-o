package com.mycompany.lab07_ek;
import java.util.ArrayList;
import java.util.Random;

public class Lab07_ek {
    
    public static Forma criarForma(){
        Random random = new Random();
        int choice;
        choice = random.nextInt(5);
        Forma forma;
        switch(choice){
            case 1:
                forma = new Quadrado(random.nextDouble(10));
                break;
            case 2:
                forma = new Triangulo(random.nextDouble(10),random.nextDouble(10));
                break;
            case 3:
                forma = new Circulo(random.nextDouble(10));
            case 4:
                forma = new Cubo(random.nextDouble(10));
                break;
            case 5:
                forma = new Esfera(random.nextDouble(10));
                break;
            case 0:
                forma = new Cilindro(random.nextDouble(10),random.nextDouble(10));
                break;
            default:
                forma = new Quadrado(random.nextDouble(10));
                break;
        }
        return forma;
    }
    
    public static void main(String[] args) {
        ArrayList<Forma> formas = new ArrayList<>();
        for(int i = 0; i < 10; i++){
            formas.add(criarForma());
        }
        for(int i = 0; i < formas.size(); i++){
            formas.get(i).imprimirDados();
        }
    }
}
