
package com.mycompany.lab07_ek;


public class Triangulo implements Forma2D {
    
    private double base, altura;
    private double area;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    public double getBase() {
        return base;
    }

    public double getAltura() {
        return altura;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        this.area = ((this.base*this.altura)/2);
        return this.area;
    }

    @Override
    public void imprimirDados() {
        System.out.println("Triâgulo");
        System.out.println("Base : "+this.base);
        System.out.println("Altura : "+this.altura);
        System.out.println("Area : "+calcularArea());
        System.out.println();
    }

}
