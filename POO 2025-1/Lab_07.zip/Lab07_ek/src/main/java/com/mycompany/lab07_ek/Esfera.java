package com.mycompany.lab07_ek;

public class Esfera implements Forma3D {
    
    private double raio;
    private double area;
    private double volume;

    public Esfera(double raio) {
        this.raio = raio;
    }

    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }
    
    @Override
    public double calcularVolume() {
        this.volume = (Math.PI*(4.0/3.0)*(Math.pow(this.raio,3)));
        return this.volume;
    }

    @Override
    public double calcularArea() {
        this.area = Math.PI*4*(Math.pow(this.raio,2));
        return this.area;
    }

    @Override
    public void imprimirDados() {
        System.out.println("Esfera");
        System.out.println("Raio : "+this.raio);
        System.out.println("Area : "+calcularArea());
        System.out.println("Volume : "+calcularVolume());
        System.out.println();
    }
    
}
