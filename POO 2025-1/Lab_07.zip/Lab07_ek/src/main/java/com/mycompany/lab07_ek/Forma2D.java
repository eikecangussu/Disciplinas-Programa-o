package com.mycompany.lab07_ek;

public interface Forma2D extends Forma {
    
}
