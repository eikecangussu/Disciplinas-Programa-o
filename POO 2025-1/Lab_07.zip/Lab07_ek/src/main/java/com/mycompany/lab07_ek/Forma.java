package com.mycompany.lab07_ek;

public interface Forma {
    double calcularArea();
    void imprimirDados();
}