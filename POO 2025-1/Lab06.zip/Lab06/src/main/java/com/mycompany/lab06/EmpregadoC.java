
package com.mycompany.lab06;

public class EmpregadoC extends Empregado{
    private double salarioBase,salarioTotal;
    private double totalVendas;
    private double percentualComissao = 0.05;

    public EmpregadoC(String nome, String cpf, String setor, double salarioBase,double totalVendas){
        super(nome,cpf,setor);
        this.salarioBase = salarioBase;
        this.totalVendas = totalVendas;
        this.salarioTotal = salarioBase + (totalVendas * this.percentualComissao);
    }
    public double getSalario(){
        return this.salarioTotal;
    }
    public String toString(){
        return String.format("\nNome do funcionario: %s\nCPF: %s\nSetor: %s\nSalário + Comissão: %s", this.getNome(),this.getCpf(),this.getSetor(),this.salarioTotal);
    }
}
