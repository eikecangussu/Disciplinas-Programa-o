/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab06;

    public class Empregado{
        private String nome,cpf,setor;
        
        public Empregado(String nome, String cpf, String setor){
            this.nome = nome;
            this.cpf = cpf; 
            this.setor = setor;
        }
        public String getNome(){
            return this.nome;
        }
        public String getCpf(){
            return this.cpf;
        }
        public String getSetor(){
            return this.setor;
        }
    }
 