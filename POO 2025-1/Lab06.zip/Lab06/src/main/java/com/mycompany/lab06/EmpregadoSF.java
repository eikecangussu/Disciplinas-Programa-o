
package com.mycompany.lab06;

public class EmpregadoSF extends Empregado{
    private double salarioMensal;
    public EmpregadoSF(String nome, String cpf, String setor, double salarioMensal){
        super(nome,cpf,setor);
        this.salarioMensal = salarioMensal;
    }
    public double getSalario(){
        return this.salarioMensal;
    }
    public String toString(){
        return String.format("\nNome do funcionario: %s\nCPF: %s\nSetor: %s\nSalário Mensal: %s", this.getNome(),this.getCpf(),this.getSetor(),this.salarioMensal);
    }
}
