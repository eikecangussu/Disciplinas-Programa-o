package com.mycompany.lab06;

import java.util.Scanner;
import java.util.ArrayList;

public class Lab06 {
        
    public static void main(String[] args) {
        ArrayList<EmpregadoSF> empregadosSF = new ArrayList<>();
        ArrayList<EmpregadoC> empregadosC = new ArrayList<>();
        boolean continua = true;
        int escolha;
        Scanner sc = new Scanner(System.in);
        while (continua){
            System.out.println("==================================================");
            System.out.println("1 - Cadastrar empregado com somente salário fixo");
            System.out.println("2 - Cadastrar empregado comissionado");
            System.out.println("3 - Listar todos os funcioários");
            System.out.println("4 - Calcular a folha de pagamento");
            System.out.println("5 - Calcular o salário de individual (Por CPF)");
            System.out.println("0 - Sair.");
            System.out.println("==================================================");
            System.out.println("Escolha uma das opções do menu:");
            if(sc.hasNextInt()){
                escolha = sc.nextInt();
                switch (escolha){
                    case 1:
                        System.out.println("Digite o nome do funcionário");
                        sc.nextLine();
                        String nome = sc.nextLine();
                        System.out.println("Digite o cpf do funcionário");
                        String cpf = sc.nextLine();
                        System.out.println("Digite o setor do funcionário");
                        String setor = sc.nextLine();
                        System.out.println("Digite o salário mensal do funcionário");
                        double salarioMensal = sc.nextDouble();
                        EmpregadoSF novo = new EmpregadoSF(nome,cpf,setor,salarioMensal);
                        empregadosSF.add(novo);
                        break;
                    case 2:
                        System.out.println("Digite o nome do funcionário");
                        sc.nextLine();
                        String nome2 = sc.nextLine();
                        System.out.println("Digite o cpf do funcionário");
                        String cpf2 = sc.nextLine();
                        System.out.println("Digite o setor do funcionário");
                        String setor2 = sc.nextLine();
                        System.out.println("Digite o salário base do funcionário");
                        double salarioBase = sc.nextDouble();
                        System.out.println("Digite o total em vendas do funcionário no mês");
                        double totalVendas = sc.nextDouble();
                        EmpregadoC novo2 = new EmpregadoC(nome2,cpf2,setor2,salarioBase,totalVendas);
                        empregadosC.add(novo2);
                        break;
                    case 3:
                        for(int i = 0 ; i < empregadosSF.size();i++){
                            System.out.println(empregadosSF.get(i).toString());
                        }
                        for(int j = 0; j < empregadosC.size();j++){
                            System.out.println(empregadosC.get(j).toString());
                        }
                        break;
                    case 4:
                        double valorFolha = 0;
                        for(int i = 0 ; i < empregadosSF.size();i++){
                            valorFolha += empregadosSF.get(i).getSalario();
                        }
                        for(int j = 0; j < empregadosC.size();j++){
                            valorFolha += empregadosC.get(j).getSalario();
                        }
                        System.out.println("A folha de pagamento total é: R$"+ valorFolha);
                        break;
                    case 5:
                        boolean encontrado = false;
                        System.out.println("Digite o CPF do funcionario");
                        sc.nextLine();
                        String cpf5 = sc.nextLine();
                        for(int i = 0 ; i < empregadosSF.size();i++){
                            if (cpf5.equals(empregadosSF.get(i).getCpf())){
                                System.out.println("Funcionário: "+ empregadosSF.get(i).getNome());
                                System.out.println("O salário é de: R$"+ empregadosSF.get(i).getSalario());
                                encontrado = true;
                                break;
                            }
                        }
                        if (!encontrado){
                            for(int j = 0 ; j < empregadosC.size();j++){
                                if (cpf5.equals(empregadosC.get(j).getCpf())){
                                    System.out.println("Funcionário: "+ empregadosC.get(j).getNome());
                                    System.out.println("O salário é de: R$"+ empregadosC.get(j).getSalario());
                                    encontrado = true;
                                    break;
                                }
                            }
                            if(!encontrado){
                                System.out.println("CPF não consta");
                                break;
                            }
                        }else break;
                    case 0:
                        System.out.println("Encerrando Programa");
                        continua = false;
                        break;
                    default:
                        System.out.println("Digite uma escolha válida");
                        break;
                }
            }
        }
    }
}
