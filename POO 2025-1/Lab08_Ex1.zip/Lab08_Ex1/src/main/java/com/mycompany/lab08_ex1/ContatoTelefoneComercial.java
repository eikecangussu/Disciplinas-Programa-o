
package com.mycompany.lab08_ex1;

public class ContatoTelefoneComercial extends ContatoTelefone{

    public ContatoTelefoneComercial(String nome, String numero) {
        super(nome, numero);
        this.tipo = "Comercial";
    }
    
    @Override
    public String getTipo(){
        return tipo;
    }
}
