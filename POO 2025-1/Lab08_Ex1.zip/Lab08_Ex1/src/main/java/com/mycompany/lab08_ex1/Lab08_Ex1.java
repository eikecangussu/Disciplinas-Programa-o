package com.mycompany.lab08_ex1;

import java.util.ArrayList;
import java.util.Scanner;

public class Lab08_Ex1 {
    
    public static int verificarEscolha(Scanner sc, String saida, int opc){
        boolean validacao = false;
        int valor = 0;
        do{
            System.out.printf(saida);
            System.out.println();
            if(sc.hasNextInt()){
                valor = sc.nextInt();
                validacao = true;
            }else{
                System.out.println("Digite um valor válido!");
                validacao = false;
            }
            sc.nextLine();
            if(validacao){
                if (opc == 1){
                    if (valor < -1 || valor > 4){
                        validacao = false; 
                        System.out.println("Digite um valor válido");
                    }
                }else if (opc == 2){
                    if (valor < 1 || valor > 4){
                        validacao = false; 
                        System.out.println("Digite um valor válido");
                    }
                }else if (opc == 3){
                    if (valor < 1 || valor > 3){
                        validacao = false; 
                        System.out.println("Digite um valor válido");
                    }
                }
            }
        }while(!validacao);
        return valor;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Contato> agenda = new ArrayList<>();
        int choice = 10;
        String saida1 = ("------------Sua Agenda--------------\n"+"Digite a ação que deseja realizar\n"+"1 - Adicionar Contato\n"+"2 - Listar todos os contatos\n"+"3 - Consultar contato (Por indice na lista de contatos)\n"+"4 - Exibir ajuda\n"+"0 - Sair do programa");
        String saida2 = ("Qual tipo de contato você deseja adicionar?\n"+"Tipos disponíveis: 1 - Telefone, 2 - E-mail, 3 - Fax, 4 - Endereço\n"+"Digite sua escolha:");
        String saida3 = ("Qual tipo de número você deseja adicionar a agenda?\n"+"1 - Adicionar número de Telefone Comercial\n"+"2 - Adicionar número de telefone Residencial\n"+"3 - Adicionar número de telefone Celular\n"+"Digite sua escolha:");
        do{
            choice = verificarEscolha(sc,saida1,1);
            switch(choice){
                case 1:
                    int escolha1 = verificarEscolha(sc,saida2,2);
                            switch (escolha1) {
                                case 1:
                                    int escolha2 = 0;
                                    escolha2 = verificarEscolha(sc,saida3,3);
                                    if(escolha2 == 1){
                                        System.out.println("Digite o nome do contato:");
                                        String nome = sc.nextLine();
                                        System.out.println("Digite o telefone:");
                                        String numCo = sc.nextLine();
                                        Contato comercial = new ContatoTelefoneComercial(nome,numCo);
                                        agenda.add(comercial);
                                    }else if(escolha2 == 2){
                                        System.out.println("Digite o nome do contato:");
                                        String nome = sc.nextLine();
                                        System.out.println("Digite o telefone:");
                                        String numRe = sc.nextLine();
                                        Contato residencial = new ContatoTelefoneComercial(nome,numRe);
                                        agenda.add(residencial);
                                    }else if(escolha2 == 3){
                                        System.out.println("Digite o nome do contato:");
                                        String nome = sc.nextLine();
                                        System.out.println("Digite o telefone:");
                                        String numCe = sc.nextLine();
                                        Contato celular = new ContatoTelefoneComercial(nome,numCe);
                                        agenda.add(celular);
                                    }
                                    System.out.println("Contato adicionado a agenda com Sucesso!");
                                    break;
                                case 2:
                                    {
                                        System.out.println("Digite o nome do contato:");
                                        String nome = sc.nextLine();
                                        System.out.println("Digite o email");
                                        String email = sc.nextLine();
                                        Contato email1 = new ContatoEmail(nome,email);
                                        agenda.add(email1);
                                        System.out.println("Contato adicionado a agenda com Sucesso!");
                                        escolha1 = 0;
                                        break;
                                    }
                                case 3:
                                    {
                                        System.out.println("Digite o nome do contato:");
                                        String nome = sc.nextLine();
                                        System.out.println("Digite o número do Fax");
                                        String fax = sc.nextLine();
                                        Contato fx = new ContatoFax(nome,fax);
                                        agenda.add(fx);
                                        System.out.println("Contato adicionado a agenda com Sucesso!");
                                        escolha1=0;
                                        break;
                                    }
                                case 4:
                                    {
                                        System.out.println("Digite o nome do contato:");
                                        String nome = sc.nextLine();
                                        System.out.println("Digite o endereço");
                                        String endereco = sc.nextLine();
                                        Contato adr = new ContatoEndereco(nome,endereco);
                                        agenda.add(adr);
                                        System.out.println("Contato adicionado a agenda com Sucesso!");
                                        escolha1=0;
                                        break;
                                    }
                                default:
                                    System.out.println("Digite uma escolha válida");
                                    break;
                            }
                    break;
                case 2:
                    for(int i = 0; i < agenda.size(); i++){
                        System.out.println(agenda.get(i).toString());
                        System.out.println();
                    }
                    break;
                case 3:
                    System.out.println("Qual contato você deseja visualizar? ");
                    System.out.println("Digite o número de referência dele na agenda.");
                        if(sc.hasNextInt()){
                            int ref = sc.nextInt();
                            if (ref < agenda.size() && ref >=0){
                                System.out.println(agenda.get(ref).toString());
                            }else{
                                System.out.println("Esse contato não existe");
                            }
                        }else{
                            System.out.println("Referência inválida");
                        }
                    break;
                case 4:
                    System.out.println("Digitando 1 você terá a opção de adicionar um novo contato a sua agenda, seja ele e-mail, endereço, fax ou telefone");
                    System.out.println("Digitando 2 você listará na tela todos os seus contatos salvos");
                    System.out.println("Digitando 3 você digitara um numéro de referencia para a sua lista de contatos, e será exibido o contato vinculado aquela referência na sua lista de contatos");
                    System.out.println("Digitando 0 você fecha o programa.");
                    break;
                case 0:
                    System.out.println("Encerrando o programa, até mais...");
                    System.out.println("-----------------------------------");
                    break;
                default:
                    System.out.println("Digite um valor válido");
                    break;
            }
        }while(choice!=0);
    }
}
