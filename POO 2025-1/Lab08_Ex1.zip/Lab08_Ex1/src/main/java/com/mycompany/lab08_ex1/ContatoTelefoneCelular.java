
package com.mycompany.lab08_ex1;

public class ContatoTelefoneCelular extends ContatoTelefone {

    public ContatoTelefoneCelular(String nome, String numero) {
        super(nome, numero);
        this.tipo = "Celular";
    }
    
    @Override
    public String getTipo(){
        return tipo;
    }
    
}
