
package com.mycompany.lab08_ex1;

public abstract class ContatoTelefone implements Contato {
    String nome;
    String numero;
    String tipo;
    
    public ContatoTelefone(String nome, String numero){
        this.nome = nome;
        this.numero = numero;
    }
    
    @Override
    public String getNome(){
        return nome;
    }
    
    @Override
    public String getContato(){
        return numero;
    }

    @Override
    public String toString() {
        return "ContatoTelefone{" + "Nome = " + nome + ", Numero = " + numero + ", Tipo = " + tipo + '}';
    }
    
}
