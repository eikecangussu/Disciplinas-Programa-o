
package com.mycompany.lab08_ex1;

public class ContatoTelefoneResidencial extends ContatoTelefone {
    
    public ContatoTelefoneResidencial(String nome, String numero){
        super(nome,numero);
        this.tipo = "Residencial";
    }
    
    @Override
    public String getTipo(){
        return tipo;
    }
}
