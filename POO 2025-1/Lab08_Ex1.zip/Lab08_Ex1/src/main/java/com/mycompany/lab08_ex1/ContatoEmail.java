
package com.mycompany.lab08_ex1;

public class ContatoEmail implements Contato {
    String nome;
    String tipo;
    String email;

    public ContatoEmail(String nome, String email) {
        this.nome = nome;
        this.email = email;
        this.tipo = "E-mail";
    }

    @Override
    public String getContato() {
        return this.email;
    }

    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public String getTipo() {
        return this.tipo;
    }

    @Override
    public String toString() {
        return "ContatoEmail{" + "Nome = " + nome + ", Tipo = " + tipo + ", Email = " + email + '}';
    }
    
}
