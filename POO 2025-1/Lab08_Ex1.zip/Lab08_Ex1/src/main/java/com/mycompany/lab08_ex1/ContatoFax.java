
package com.mycompany.lab08_ex1;

public class ContatoFax implements Contato {
    String nome;
    String tipo;
    String numeroF;

    public ContatoFax (String nome, String numeroF) {
        this.nome = nome;
        this.numeroF = numeroF;
        this.tipo = "Fax";
    }

    @Override
    public String getContato() {
        return this.numeroF;
    }

    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public String getTipo() {
        return this.tipo;
    }

    @Override
    public String toString() {
        return "ContatoFax{" + "Nome = " + nome + ", Tipo = " + tipo + ", Numero do Fax = " + numeroF + '}';
    }
    
}
