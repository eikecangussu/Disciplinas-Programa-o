
package com.mycompany.lab08_ex1;


public class ContatoEndereco implements Contato {
    String nome;
    String tipo;
    String endereco;

    public ContatoEndereco(String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
        this.tipo = "Endereço";
    }

    @Override
    public String getContato() {
        return this.endereco;
    }

    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public String getTipo() {
        return this.tipo;
    }

    @Override
    public String toString() {
        return "ContatoEndereco{" + "Nome = " + nome + ", Tipo = " + tipo + ", Endereco = " + endereco + '}';
    }
    
}
