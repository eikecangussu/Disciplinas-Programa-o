package com.mycompany.lab08_ex1;

public interface Contato {
    String getContato();
    String getNome();
    String getTipo();
    String toString();
}
