package com.mycompany.contatosnoarquivo;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

public class ContatosNoArquivo {
    
    public static void adicionarContato(String nomeDoArquivo,Scanner sc){
        System.out.println("Digite o nome do contato");
        String nome = sc.nextLine();
        System.out.println("Digite o numero de telefone");
        String numero = sc.nextLine();
        String formatada = nome+","+numero;
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(nomeDoArquivo,true))){
            bw.write(formatada);
            bw.newLine();
            System.out.println("Dados salvos com sucesso");
        }catch(IOException e){
            System.out.println("ERRO no salvamento dos dados:" + e.getMessage());
        }
    }
    
    public static void imprimirContatos(String nomeDoArquivo){
        try(BufferedReader br = new BufferedReader(new FileReader(nomeDoArquivo))){
            String linha;
            while((linha = br.readLine())!= null){
                String[] campos = linha.split(",");
                String nome = campos[0];
                String telefone = campos[1];
                System.out.printf("Nome: %s \nTelefone: %s\n",nome,telefone);
            }
        }catch(IOException e){
            System.out.println("Erro de leitura");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String choice = "9";
        String nomeDoArquivo = "contatos.csv";
        do{
            System.out.println("-------menu--------");
            System.out.println("1 - Adicionar contato");
            System.out.println("2 - Listar contatos");
            System.out.println("0 - Sair do programa");
            choice = sc.nextLine();
            switch(choice){
                case "1":
                    adicionarContato(nomeDoArquivo,sc);
                    break;
                case "2":
                    System.out.println("Listando todos os contatos: . . .");
                    imprimirContatos(nomeDoArquivo);
                    break;
                case "0":
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Digite um valor válido");
            }
        }while(!choice.equals("0"));
    }
    
}