
package com.mycompany.lab08_ex2;
import java.math.BigDecimal;
       
public class Lab08_Ex2 {

    public static void main(String[] args) {
        Codigo<Integer,String> c1 = new Codigo<>(22,"CLT");
        ProdutoG<Codigo> p1 = new ProdutoG<>(c1,"Casaco",20.99);
        System.out.println(p1.toString());
        
        Integer c2 = 32;
        String preco2 = "A definir";
        Produto2<Integer,String> p2 = new Produto2<>(c2,"Relógio",preco2);
        System.out.println(p2.toString());
        
        ValorM<String> vm1 = new ValorM<>("Sob consulta");
        Codigo<String,String> c3 = new Codigo<>("000","LVR");
        Produto2<Codigo,ValorM> p3 = new Produto2<>(c3,"Livro",vm1);
        System.out.println(p3.toString());

        BigDecimal bid = new BigDecimal("5.08979");
        ValorM<BigDecimal> vm2 = new ValorM<>(bid);
        Codigo<String,String> c4 = new Codigo<>("296","BTC");
        Produto2<Codigo,ValorM> p4 = new Produto2<>(c4,"Bitcoin2010",vm2);
        System.out.println(p4.toString());
    }
}
