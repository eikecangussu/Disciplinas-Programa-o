
package com.mycompany.lab08_ex2;

public class ValorM<T extends Comparable<T>> {
    private T valor;

    public ValorM(T valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "ValorM{" + "valor=" + valor + '}';
    }
}
