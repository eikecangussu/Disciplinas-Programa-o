
package com.mycompany.lab08_ex2;

public class Codigo<T,K> {
    private T letras;
    private K numeros;

    public Codigo(T letras, K numeros) {
        this.letras = letras;
        this.numeros = numeros;
    }

    @Override
    public String toString() {
        return "Codigo: "+ letras + "-" + numeros + '.';
    }
    
    
}
