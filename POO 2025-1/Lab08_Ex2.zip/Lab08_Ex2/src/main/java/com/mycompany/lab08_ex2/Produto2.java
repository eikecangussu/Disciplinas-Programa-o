package com.mycompany.lab08_ex2;

public class Produto2<T,K> {
    private T codigo;
    private String descricao;
    private K preco;
    
    public Produto2(T cod,String descr, K pr) {
        codigo = cod;
        descricao = descr;
        preco = pr;
    }
    public T getCodigo() { return codigo; }
    
    public String getDescricao() { return descricao; }
    
    public K getPreco() { return preco; }
    
    @Override
    public String toString() {
        return "Produto2{" + "codigo=" + codigo + ", descricao=" +descricao + ", preco=" + preco + "}";
    }
}
