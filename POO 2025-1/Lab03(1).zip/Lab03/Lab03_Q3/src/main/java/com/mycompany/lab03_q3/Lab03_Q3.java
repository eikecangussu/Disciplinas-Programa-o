package com.mycompany.lab03_q3;

import java.util.Scanner;

public class Lab03_Q3 {
    
    public static void imprimeMenu(Produto um,Produto dois, Produto tres,Produto quatro,Carrinho cliente){
    System.out.println(" Mercado Bh");
    System.out.println("Produtos disponíveis:");
    System.out.println("1 - "+um.nome+" Valor:RS"+um.preco+" Estoque:"+um.estoque);
    System.out.println("2 - "+dois.nome+" Valor:RS"+dois.preco+" Estoque:"+dois.estoque);
    System.out.println("3 - "+tres.nome+" Valor:RS"+tres.preco+" Estoque:"+tres.estoque);
    System.out.println("4 - "+quatro.nome+" Valor:RS"+quatro.preco+" Estoque:"+quatro.estoque);
    System.out.println("0 - Finalizar pedido.");
    System.out.println("Produtos no carrinho:"+cliente.numProdutos);
    System.out.println("Valor total da compra:R$"+cliente.valorCompra);
}

    public static void main(String[] args) {
        //Declaração dos objetos
        Produto salsicha = new Produto();
        Produto pao = new Produto();
        Produto extratoDeTomate=  new Produto();
        Produto batataPalha = new Produto();
        Carrinho cliente = new Carrinho();
        salsicha.nome= "Salsicha";
        salsicha.preco = 5.60;
        salsicha.estoque=10;
        pao.nome="Pão";
        pao.preco=1.0;
        pao.estoque=100;
        extratoDeTomate.nome="Extrato de Tomate";
        extratoDeTomate.preco=2.50;
        extratoDeTomate.estoque=20;
        batataPalha.nome="Batata Palha";
        batataPalha.preco=6.60;
        batataPalha.estoque=15;
        
        //Menu de compra
        
        int choice;
        int choice2;
        Scanner sc = new Scanner(System.in);
        imprimeMenu(salsicha,pao,extratoDeTomate,batataPalha,cliente);
        choice=6;
        while(choice!=0){
            choice = sc.nextInt();
            boolean v;
            switch(choice){
                case 1:
                    System.out.println("Quanto desse produto você quer adicionar ao carrinho?");
                    choice2 = sc.nextInt();
                    v = salsicha.compra(choice2);
                    if(v==true)cliente.adicionarProduto(choice2, salsicha.preco);
                    break;
                case 2:
                    System.out.println("Quanto desse produto você quer adicionar ao carrinho?");
                    choice2 = sc.nextInt();
                    v = pao.compra(choice2);
                    if(v==true)cliente.adicionarProduto(choice2, pao.preco);
                    break;
                case 3:
                    System.out.println("Quanto desse produto você quer adicionar ao carrinho?");
                    choice2 = sc.nextInt();
                    v = extratoDeTomate.compra(choice2);
                    if(v==true)cliente.adicionarProduto(choice2, extratoDeTomate.preco);
                    break;
                case 4:
                    System.out.println("Quanto desse produto você quer adicionar ao carrinho?");
                    choice2 = sc.nextInt();
                    v = batataPalha.compra(choice2);
                    if(v==true)cliente.adicionarProduto(choice2, batataPalha.preco);
                    break;
                case 0:
                    System.out.println("Prosseguindo para o pagamento...");
                    System.out.println("Escolha sua forma de pagamento,1 para dinheiro, 2 para cheque, 3 para cartão.");
                    int pagamento = sc.nextInt();
                    boolean cPagamento;
                    cPagamento = cliente.pagamento(pagamento);
                    if (cPagamento==true){
                        System.out.println("Pagamento confirmado");
                    }else{
                        System.out.println("Falha no pagamento");
                    }
                    break;
            }
        if (choice!=0)imprimeMenu(salsicha,pao,extratoDeTomate,batataPalha,cliente);
        }
    }
}
