package com.mycompany.lab03_q3;


public class Produto {
    String nome;
    double preco;
    int estoque;
    
    public boolean compra(int quantidade){
        
        if (quantidade>estoque){
            System.out.println("Estoque insuficiente");
            return false;
        }
        else{
            this.estoque-=quantidade;
            System.out.println("Adicionado ao carrinho.");
            return true;
        }
    }
}    