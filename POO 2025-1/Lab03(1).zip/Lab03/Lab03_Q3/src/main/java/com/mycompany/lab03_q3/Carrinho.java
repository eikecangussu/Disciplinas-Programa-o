package com.mycompany.lab03_q3;
import java.util.Scanner;

public class Carrinho {
    
    int numProdutos;
    double valorCompra;
    
    void adicionarProduto(int qtdd,double valorP){
        this.numProdutos+=qtdd;
        this.valorCompra+=valorP*qtdd;
    }
    
    boolean pagamento(int fPagamento){
        switch (fPagamento){
            case 1:
                double valorPago;
                Scanner sc = new Scanner(System.in);
                System.out.println("Valor a pagar: R$"+valorCompra);
                System.out.println("Insira o valor em cédulas:");
                valorPago = sc.nextDouble();
                System.out.println("Você escolheu o pagamento em dinheiro e entregou R$"+valorPago+".");
                if (valorPago<this.valorCompra){
                    System.out.println("Valor insuficiente para efetuar o pagamento da compra.");
                    return false;
                }else{
                    double troco=valorPago-this.valorCompra;
                    System.out.println("Pagamento concluído. Seu troco é de "+troco+".");
                    return true;
                }
            case 2:
                System.out.println("Você escolheu o pagamento em cheque.");
                System.out.println("Pagamento concluído");
                return true;
            case 3:
                System.out.println("Você escolheu o pagamento com o cartão de crédito");
                System.out.println("Pagamento concluído");
                return true;        
        }
        return false;
    }
}
