
package com.mycompany.lab03_q6;

public class Lab03_Q6 {
    
    public static void main(String[] args) {
        
        CadernoDeEnderecos meuEndereco = new CadernoDeEnderecos();
        meuEndereco.nome = "Fulano";
        meuEndereco.bairro = "Santa Rita";
        meuEndereco.rua = "Francisco de Assis";
        meuEndereco.numeroDaCasa = "97";
        meuEndereco.cep = "39814-000";
        
        meuEndereco.imprimirEndereco();
        meuEndereco.atualizarEndereco("Cicrano","Guriri","2","1692","70000-000");
        System.out.println();
        meuEndereco.imprimirEndereco();
        
    }
}