
package com.mycompany.lab03_q6;

public class CadernoDeEnderecos {
    
        //variáveis de instancia necessárias
        String nome;
        String bairro;
        String rua;
        String numeroDaCasa;
        String cep;
        
        //métodos necessarios
        void atualizarEndereco(String novonome,String novobairro, String novarua,String numeroDaCasa,String novocep){
            
            this.nome=novonome;
            this.bairro=novobairro;
            this.rua=novarua;
            this.numeroDaCasa=numeroDaCasa;
            this.cep=novocep;
            
        }
        
        void imprimirEndereco(){
            
            System.out.println(this.nome);
            System.out.println(this.bairro);
            System.out.println(this.rua);
            System.out.println(this.numeroDaCasa);
            System.out.println(this.cep);
            
        }
}
