package com.mycompany.lab3_q2;


public class Aluno {
    
    //Atributos
    String nome;
    String matricula;
    double nota1,nota2,trabalho;
    
    public double mediaP(){
        double media;
        nota1 = nota1*2.5;
        nota2 = nota2*2.5;
        trabalho = trabalho*2;
        media= ((nota1+nota2+trabalho)/7);
        
        return media;
    }
    //considerando que a média é 70% do total
    public double pFinal(double media){
        if(media>=7){
            return 0;
        }
        else{
            return 7-media;
        }
}
}