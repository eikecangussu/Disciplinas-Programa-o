
package com.mycompany.lab3_q2;


public class Lab3_Q2 {

    public static void main(String[] args) {
        Aluno um = new Aluno();
        um.nome = "fulano";
        um.matricula = "1";
        um.nota1 = 10;
        um.nota2 = 0;
        um.trabalho = 0;
        double media1 = um.mediaP();
        System.out.println("Media do aluno "+um.nome+":"+media1);
        double final1 = um.pFinal(media1);
        System.out.println("Nota necessaria na prova final "+um.nome+":"+final1);
        
        Aluno dois = new Aluno();
        dois.nome="Cicrano";
        dois.matricula= "2";
        dois.nota1=6;
        dois.nota2=6;
        dois.trabalho=6;
        double media2 = um.mediaP();
        System.out.println("Media do aluno "+dois.nome+":"+media2);
        double final2 =um.pFinal(media2);
        System.out.println("Nota necessaria na prova final "+dois.nome+":"+final2);
    }
}
