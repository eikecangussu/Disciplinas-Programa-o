
package com.mycompany.lab03_q4;
import java.util.Scanner;

public class Lab03_Q4 {
    
    public static void imprimirAgenda(Agenda a){
        System.out.println("1 - "+a.a.nome+":"+a.a.numero);
        System.out.println("2 - "+a.b.nome+":"+a.b.numero);
        System.out.println("3 - "+a.c.nome+":"+a.c.numero);
    }
    
    public static void main(String[] args) {
        //Construindo objetos
        Agenda amigos = new Agenda();
        amigos.a.nome="Fulano";
        amigos.a.numero=123455678;
        amigos.b.nome="Cicrano";
        amigos.b.numero=889756478;
        amigos.c.nome="Beltrano";
        amigos.c.numero=876398562;
        
        Contato aBuscar;
        System.out.println("Para buscar um contato digite 1, para editar um contato existente digite 2");
        Scanner sc = new Scanner(System.in);
        int v= sc.nextInt();
        if (v==1){
            aBuscar=amigos.buscarContato("Fulano");
            if (aBuscar!=null){
                System.out.println(aBuscar.nome);
                System.out.println(aBuscar.numero);
            } 
        }
        if (v==2){
            imprimirAgenda(amigos);
            System.out.println("Qual contato deseja editar?");
            int choice = sc.nextInt();
            sc.nextLine();
            String novonome;
            long novonumero;
            if(choice!=1&&choice!=2&&choice!=3)System.out.println("Valor inválido");
            else{
            if (choice==1){
                System.out.println("Qual o novo nome?");
                novonome = sc.nextLine();
                System.out.println("Qual o novo Numero?");
                novonumero = sc.nextLong();
                amigos.a.editarContato(novonome,novonumero);
                imprimirAgenda(amigos);
            }
            if (choice==2){
                System.out.println("Qual o novo nome?");
                novonome= sc.nextLine();
                System.out.println("Qual o novo Numero?");
                novonumero= sc.nextLong();
                amigos.b.editarContato(novonome,novonumero);
                imprimirAgenda(amigos);
            }
            if (choice==3){
                System.out.println("Qual o novo nome?");
                novonome = sc.nextLine();
                System.out.println("Qual o novo Numero?");
                novonumero = sc.nextLong();
                amigos.c.editarContato(novonome,novonumero);
                imprimirAgenda(amigos);
            }
        }
        }
        }
    }

