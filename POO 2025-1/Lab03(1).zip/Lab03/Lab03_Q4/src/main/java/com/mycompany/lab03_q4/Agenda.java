/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab03_q4;

public class Agenda {
    
    Contato a = new Contato();
    Contato b = new Contato();
    Contato c = new Contato();
    
    Contato buscarContato(String nome){
        if(nome.equals(a.nome)){
            System.out.println("Contato encontrado");
            return a;
        }
        if(nome.equals(b.nome)){
            System.out.println("Contato encontrado");
            return b;
        }
        if(nome.equals(c.nome)){
            System.out.println("Contato encontrado");
            return c;
        }
        else {
            System.out.println("Contato não encontrado");
            return null;
        }
    }
}
