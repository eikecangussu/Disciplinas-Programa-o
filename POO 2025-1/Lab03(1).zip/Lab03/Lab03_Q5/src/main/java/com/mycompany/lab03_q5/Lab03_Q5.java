
package com.mycompany.lab03_q5;
import java.util.Scanner;

public class Lab03_Q5 {
    


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //criando objetos
        Pessoa fulano = new Pessoa();
        fulano.nome="Fulano da Silva";
        Pessoa beltrano = new Pessoa();
        beltrano.nome= "Beltrano de Sousa";
        
        Livro aCgf = new Livro();
        aCgf.nomeDoLivro= "As cronicas de gelo e fogo";
        aCgf.autor= "George R.R. Martin";
        Livro roJu = new Livro();
        roJu.nomeDoLivro= "Romeu e Julieta";
        roJu.autor= "William Shakespeare";
        
        //verificação se é pessoa cadastrada
        System.out.println("Quem deseja efetuar o emprestimo?");
        String nome = sc.nextLine();
        if (!nome.equals(fulano.nome)&&!nome.equals(beltrano.nome)){
            System.out.println("Pessoa não cadastrada");
        }else {
            if(nome.equals(fulano.nome)){
                //Verificação se o livro procurado está cadastrada
                System.out.println("Qual o nome do livro a ser emprestado?");
                String livro= sc.nextLine();
                if (aCgf.nomeDoLivro.equals(livro)){
                    fulano.emprestimo.calcularDevolucao(aCgf);
                }else if(roJu.nomeDoLivro.equals(livro)){
                    fulano.emprestimo.calcularDevolucao(roJu);
                }else{
                    System.out.println("Livro não encontrado");
                }
            }else
            {
                System.out.println("Qual o nome do livro a ser emprestado?");
                String livro= sc.nextLine();
                if (aCgf.nomeDoLivro.equals(livro)){
                    beltrano.emprestimo.calcularDevolucao(aCgf);
                }else if(roJu.nomeDoLivro.equals(livro)){
                    beltrano.emprestimo.calcularDevolucao(roJu);
                }else{
                    System.out.println("Livro não encontrado");
                }
            }
        }
    }
}

