
package com.mycompany.lab03_q5;

public class Pessoa {
    String nome;
    Emprestimo emprestimo = new Emprestimo();
}
