
package com.mycompany.lab03_q5;
import java.time.LocalDate;

public class Emprestimo {
    
    Livro livro;
    LocalDate dataAtual;
    LocalDate dataDevolucao;
    
    public void calcularDevolucao(Livro livro1){
        if(livro1.situacao.equals("disponivel")){
            this.livro=livro1;
            this.dataAtual= LocalDate.now();
            this.dataDevolucao= dataAtual.plusDays(7);
            System.out.println("Emprestimo efetivado");
    }
        else System.out.println("Livro indisponível");
    }
}
