/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_03;

public class Ponto {
     //Atributos
    double x;
    double y;
    
    //Métodos
    public double calcularDistancia(Ponto outroPonto){
        double dx = this.x - outroPonto.x;
        double dy = this.y - outroPonto.y;
        
        return Math.sqrt(dx*dx+dy*dy);
        
    }
}
