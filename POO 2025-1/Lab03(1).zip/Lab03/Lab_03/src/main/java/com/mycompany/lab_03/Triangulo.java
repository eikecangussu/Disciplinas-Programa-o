/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_03;


public class Triangulo {
    Ponto A;
    Ponto B;
    Ponto C;
    
    public double perimetro(){
        double ladoA = A.calcularDistancia(B);
        double ladoB =B.calcularDistancia(C);
        double ladoC = C.calcularDistancia(A);
        
        return ladoA+ladoB+ladoC;
    }
}
