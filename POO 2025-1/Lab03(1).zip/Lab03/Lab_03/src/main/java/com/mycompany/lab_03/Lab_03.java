/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab_03;

public class Lab_03 {

   public static void main(String[] args) {

        Triangulo t = new Triangulo();
        Ponto p1,p2,p3;
        p1 = new Ponto();
        p2 = new Ponto();
        p3 = new Ponto();
        p1.x = 1;
        p1.y = 2;
        p2.x = 4;
        p1.y = 6;
        p3.x = 6;
        p1.y = 1;
        
        t.A=p1;
        t.B=p2;
        t.C=p3;
        
        System.out.println("O perimetro é :"+t.perimetro());
        
        }
    }
