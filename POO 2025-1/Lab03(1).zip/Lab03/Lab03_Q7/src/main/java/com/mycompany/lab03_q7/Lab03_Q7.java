
package com.mycompany.lab03_q7;

public class Lab03_Q7 {

    public static void main(String[] args) {
        
        timeFutebol Cruzeiro = new timeFutebol(20,15,4,6,2,2,10);
        Cruzeiro.imprimirTime();
        
        
    }
}
