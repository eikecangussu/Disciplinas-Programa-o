
package com.mycompany.lab03_q7;


public class timeFutebol {
    int pontos,golsMarcados,saldoDeGols,golsSofridos,vitorias,derrotas,empates,partidasJogadas;
    
    
    public timeFutebol(){
        this.pontos=0;
        this.golsMarcados=0;
        this.golsSofridos=0;
        this.saldoDeGols=0;
        this.vitorias=0;
        this.derrotas=0;
        this.empates=0;
        this.partidasJogadas=0;
    }
    public timeFutebol(int pontos,int golsMarcados,int golsSofridos,int vitorias,int derrotas,int empates,int partidasJogadas){
        this.pontos=pontos;
        this.golsMarcados=golsMarcados;
        this.golsSofridos=golsSofridos;
        this.saldoDeGols=golsMarcados-golsSofridos;
        this.vitorias=vitorias;
        this.derrotas=derrotas;
        this.empates=empates;
        this.partidasJogadas=partidasJogadas;
    }
    public void imprimirTime(){
        System.out.println("Pontos:"+this.pontos);
        System.out.println("Partidas jogadas:"+this.partidasJogadas);
        System.out.println("Vitorias:"+this.vitorias);
        System.out.println("Derrotas:"+this.derrotas);
        System.out.println("Empates:"+this.empates);
        System.out.println("Gols marcados:"+this.golsMarcados);
        System.out.println("Gols sofridos:"+this.golsSofridos);
        System.out.println("Saldo de gols:"+this.saldoDeGols);
    }
    
    public void partida(int golsSofridos,int golsMarcados){
        this.partidasJogadas+=1;
        int saldoPartida = golsMarcados - golsSofridos;
        if(golsSofridos==golsMarcados)this.empates+=1;
        if(golsSofridos<golsMarcados)this.vitorias+=1;
        if(golsSofridos>golsMarcados)this.derrotas+=1;
        this.saldoDeGols+= saldoPartida;
    }
}
