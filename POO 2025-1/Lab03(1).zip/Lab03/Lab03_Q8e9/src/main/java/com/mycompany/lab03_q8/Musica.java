
package com.mycompany.lab03_q8;

public class Musica {
    String nomeDaMusica;
    String compositor;
    String album;
    String interprete;
    
    public Musica(String nomeDaMusica,String compositor,String album,String interprete){
        this.nomeDaMusica= nomeDaMusica;
        this.compositor= compositor;
        this.album= album;
        this.interprete= interprete;
    }
    
    public void imprimirMusica(){
        System.out.println("Nome da Música: "+nomeDaMusica);
        System.out.println("Compositor: "+compositor);
        System.out.println("Albúm: "+album);
        System.out.println("Cantor: "+interprete);
    }
}
