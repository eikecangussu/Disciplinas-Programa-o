
package com.mycompany.lab03_q8;

public class Lab03_Q8 {

    public static void main(String[] args) {
        Musica dec = new Musica("Declaracao de amor","Altay Veloso","Daniel","Daniel");
        dec.imprimirMusica();
        System.out.println();
        
        //Questao 9
        Musica[] CDDeMusicas = new Musica[4];
        CDDeMusicas[0] = dec;
        CDDeMusicas[1] = new Musica("Cuitelinho","Antonio Xando, Paulo Vanzolini","Meu Reino Encantado","Daniel, Pena Branca");
        CDDeMusicas[2] = new Musica("Poeira da Estrada","João Paulo, Rick","Meu Reino Encantado","Daniel");
        CDDeMusicas[3] = new Musica("Dificil não falar de amor","Geraldo Antônio","Raizes","Daniel");
        for(int i=0;i<4;i++){ 
            System.out.println();
            CDDeMusicas[i].imprimirMusica();
        }
    }
}