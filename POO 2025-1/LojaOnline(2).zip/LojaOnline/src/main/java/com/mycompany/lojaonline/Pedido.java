
package com.mycompany.lojaonline;

/* @author eikec */

public class Pedido{
    
	private final int IDdoPedido;
	private final String descricao;
	private final double valorPedido;
	private static int proximoId =1001;
	private static int totalPedidos;
	private static double valorTotal;

	public Pedido(String descricao, double valorPedido) {
   	 
    	this.descricao = descricao;
    	this.valorPedido = valorPedido;
    	this.IDdoPedido= proximoId;
    	proximoId+=1;
    	totalPedidos+=1;
    	valorTotal+=this.valorPedido;
           	 
	}
    
	public int getIDdoPedido() {
    	return IDdoPedido;
	}

	public String getDescricao() {
    	return descricao;
	}

	public double getValorPedido() {
    	return valorPedido;
	}
	public String exibirDetalhesDoPedido(){
    	return String.format("Pedido Nº %d \nDescrição do Pedido:%s \nValor do pedido:%f",IDdoPedido,descricao,valorPedido);
	}

	public static int getTotalPedidos() {
    	return totalPedidos;
	}

	public static double getvalorTotal() {
    	return valorTotal;
	}
    
	public static String gerarRelatorioGeral(){
    	return String.format("Total de pedidos realizados:%d \n Valor total pedidos:%f",totalPedidos,valorTotal);
	}

}