
package com.mycompany.lojaonline;
import java.util.Scanner;
import java.util.ArrayList;

/* @author eikec */
public class LojaOnline {

    public static void main(String[] args) {
        ArrayList<Pedido> pedidos= new ArrayList<>();
        Pedido a = new Pedido("Air fryer Philco",255.99);
        pedidos.add(a);
        Pedido b = new Pedido("Liquidificador Mondial",105.99);
        pedidos.add(b);
        Pedido c = new Pedido("Panela Tramontina",89.99);
        pedidos.add(c);
        Pedido d = new Pedido("Copo americano",5.99);
        pedidos.add(d);
        Pedido e = new Pedido("Faca tramontina",65.99);
        pedidos.add(e);
        Scanner sc = new Scanner(System.in);
        String escolha;
        do{
            System.out.println("Deseja cadastrar um novo pedido?");
            System.out.println("Responda com S para sim e N para não");
            escolha = sc.nextLine();
            switch(escolha){
                case "S":
                    System.out.println("Cadastrando pedido...");
                    System.out.println("Qual produto você está comprando?");
                    String descricao = sc.nextLine();
                    System.out.println("Qual o valor do produto?");
                    double valor = sc.nextDouble();
                    Pedido novo = new Pedido(descricao,valor);
                    pedidos.add(novo);
                    sc.nextLine();
                    break;
                case "N":
                    System.out.println("Finalizando...");
                    System.out.println(Pedido.gerarRelatorioGeral());
                    break;
                default:
                    System.out.println("Entrada inválida");
                    break;
            }
        }while(!escolha.equals("N"));
    }
}
