
package com.mycompany.lab09_1;
import java.util.Scanner;

public class LAb09_1 {
    
    //função de verificação questão 2
    
    public static int verificarEscolha(Scanner sc, String saida, int opc){
        boolean validacao = false;
        int valor = 0;
        do{
            System.out.printf(saida);
            System.out.println();
            if(sc.hasNextInt()){
                valor = sc.nextInt();
                validacao = true;
            }else{
                System.out.println("Digite um valor válido!");
                validacao = false;
            }
            sc.nextLine();
            if(validacao){
                if (opc == 2){
                    if (valor == 0){
                        validacao = false; 
                        System.out.println("Digite um valor válido");
                    }
                }
            }
        }while(!validacao);
        return valor;
    }

    public static void main(String[] args) {
        //EX1
        
        int[] vetor = new int[] {2, 4, 6, 8, 10, 12};
        for (int i = 0; i <= 12; i++) {
            try{
                System.out.println(vetor[i]);
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.println("Fim do vetor");
                break;
            }
        }
        
        //EX2
        
        Scanner teclado = new Scanner(System.in);
        System.out.println();
        System.out.println("Eu sei dividir!");
        String saida1 = "Informe o primeiro valor: ";
        int x = verificarEscolha(teclado,saida1,1);
        String saida2 = "Informe o segundo valor: ";
        int y = verificarEscolha(teclado, saida2, 2);
        double r = (x / y);
        System.out.println("O resultado da divisão é " + r);
    }
}
